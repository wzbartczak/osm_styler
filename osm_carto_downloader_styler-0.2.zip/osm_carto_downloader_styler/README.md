# OSM Carto Downloader & Styler 0.2

Wtyczka QGIS udostępnia dwa tryby pracy:

1. pobranie danych OpenStreetMap dla prostokąta zaznaczonego na mapie;
2. otwarcie lokalnego pliku `.osm.pbf`, `.pbf`, `.osm` albo `.gpkg`.

W obu przypadkach wtyczka tworzy cztery standardowe warstwy OGR, stosuje
style QML i lokalne ikony SVG oparte na OpenStreetMap Carto, ustawia kolejność
warstw oraz centruje widok na danych.

## Pobieranie obszaru

1. Wybierz **Wektor → OSM Carto Downloader & Styler → Pobierz i wystylizuj
   OSM z prostokąta…**.
2. Przeciągnij prostokąt na mapie.
3. Wskaż miejsce zapisania pliku `.gpkg`.
4. Poczekaj na zakończenie pobierania i automatyczne wystylizowanie danych.

Zaznaczenie jest przeliczane z CRS mapy do EPSG:4326. Wtyczka wybiera
najmniejszy regionalny PBF Geofabrik obejmujący obszar. Pobieranie można
wznowić, wynik jest sprawdzany sumą MD5 i trafia do pamięci podręcznej.
Wybrany obszar jest następnie wycinany lokalnie przez GDAL.

## Otwieranie lokalnego pliku

Wybierz **Wczytaj lokalny PBF lub OSM ze stylem…** i wskaż plik `.osm.pbf`,
`.pbf`, `.osm` albo `.gpkg`.

Wtyczka utworzy grupę `OSM Carto 0.2 — nazwa_pliku` zawierającą, od góry:

1. `points` — punkty i POI;
2. `multilinestrings` — relacje liniowe i szlaki turystyczne;
3. `lines` — drogi, koleje i cieki;
4. `multipolygons` — poligony.

## Instalacja

1. W QGIS wybierz **Wtyczki → Zarządzaj i instaluj wtyczki**.
2. Otwórz kartę **Instaluj z ZIP**.
3. Wskaż archiwum `osm_carto_downloader_styler-0.2.zip`.
4. Aktywuj **OSM Carto Downloader & Styler**.

## Zgodność

- QGIS 3.22–3.99;
- standardowy sterownik GDAL/OGR OSM;
- dostęp do Internetu wymagany wyłącznie dla funkcji pobierania.

## Licencje ikon

- OpenStreetMap Carto — CC0 1.0;
- Temaki — CC0 1.0 (`boulder1.svg`);
- Maki — CC0 1.0, pliki zgodności nieużywane przez bieżący `points.qml`.

Kopie licencji znajdują się w katalogu `Symbols_PBF`.

