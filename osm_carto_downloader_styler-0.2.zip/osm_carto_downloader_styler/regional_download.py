"""Resumable Geofabrik PBF download and local GDAL extraction."""

from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from qgis.core import QgsTask


INDEX_URL = "https://download.geofabrik.de/index-v1.json"
USER_AGENT = "OSM-Carto-Downloader-Styler/0.2 QGIS-Plugin"
CHUNK_SIZE = 1024 * 1024


class RegionalDownloadError(RuntimeError):
    """A user-facing regional download or extraction failure."""


class RegionalPbfTask(QgsTask):
    """Download a cached regional PBF and extract the selected bbox to GPKG."""

    def __init__(self, bbox, output_path, cache_dir, on_finished):
        super().__init__("Pobieranie regionalnych danych OSM", QgsTask.CanCancel)
        self.bbox = tuple(float(value) for value in bbox)
        self.output_path = Path(output_path)
        self.cache_dir = Path(cache_dir)
        self.on_finished_callback = on_finished
        self.error_message = ""
        self.region_name = ""

    def run(self):
        try:
            self.cache_dir.mkdir(parents=True, exist_ok=True)
            catalogue = self._load_catalogue()
            region = select_smallest_extract(catalogue, self.bbox)
            self.region_name = strip_html(region.get("name") or region["id"])
            pbf_url = region["urls"]["pbf"]
            pbf_path = self.cache_dir / Path(pbf_url).name
            self.setProgress(3)
            self._download_verified(pbf_url, pbf_path)
            if self.isCanceled():
                return False
            self.setProgress(88)
            extract_to_gpkg(pbf_path, self.output_path, self.bbox)
            self.setProgress(100)
            return True
        except Exception as exc:
            self.error_message = str(exc)
            return False

    def _load_catalogue(self):
        cached_index = self.cache_dir / "geofabrik-index-v1.json"
        try:
            raw_index = self._fetch_bytes(INDEX_URL)
            catalogue = json.loads(raw_index.decode("utf-8"))
            temporary_index = cached_index.with_suffix(".json.tmp")
            temporary_index.write_bytes(raw_index)
            os.replace(temporary_index, cached_index)
            return catalogue
        except (RegionalDownloadError, UnicodeDecodeError, json.JSONDecodeError):
            if cached_index.is_file():
                return json.loads(cached_index.read_text(encoding="utf-8"))
            raise

    def finished(self, result):
        self.on_finished_callback(bool(result), self)

    def _fetch_bytes(self, url, attempts=3):
        last_error = None
        for attempt in range(attempts):
            if self.isCanceled():
                raise RegionalDownloadError("Pobieranie zostało anulowane.")
            try:
                request = Request(url, headers={"User-Agent": USER_AGENT})
                with urlopen(request, timeout=60) as response:
                    return response.read()
            except (HTTPError, URLError, TimeoutError, OSError) as exc:
                last_error = exc
                if attempt + 1 < attempts:
                    time.sleep(2**attempt)
        raise RegionalDownloadError(f"Nie można pobrać {url}: {last_error}")

    def _download_verified(self, url, destination):
        expected_md5 = self._expected_md5(url)
        if destination.is_file():
            if not expected_md5 or file_md5(destination) == expected_md5:
                self.setProgress(87)
                return

        partial = destination.with_suffix(destination.suffix + ".part")
        last_error = None
        for attempt in range(4):
            if self.isCanceled():
                raise RegionalDownloadError("Pobieranie zostało anulowane.")
            offset = partial.stat().st_size if partial.exists() else 0
            headers = {"User-Agent": USER_AGENT}
            if offset:
                headers["Range"] = f"bytes={offset}-"
            try:
                request = Request(url, headers=headers)
                with urlopen(request, timeout=90) as response:
                    status = getattr(response, "status", response.getcode())
                    append = offset > 0 and status == 206
                    if not append:
                        offset = 0
                    length = int(response.headers.get("Content-Length") or 0)
                    total = offset + length if length else 0
                    mode = "ab" if append else "wb"
                    received = offset
                    with partial.open(mode) as stream:
                        while True:
                            if self.isCanceled():
                                raise RegionalDownloadError(
                                    "Pobieranie zostało anulowane."
                                )
                            block = response.read(CHUNK_SIZE)
                            if not block:
                                break
                            stream.write(block)
                            received += len(block)
                            if total:
                                self.setProgress(5 + min(80, received * 80 / total))
                if expected_md5 and file_md5(partial) != expected_md5:
                    partial.unlink(missing_ok=True)
                    last_error = RegionalDownloadError(
                        "Suma MD5 pobranego PBF jest niezgodna."
                    )
                    if attempt + 1 < 4:
                        time.sleep(2**attempt)
                        continue
                    raise last_error
                os.replace(partial, destination)
                return
            except RegionalDownloadError:
                raise
            except (HTTPError, URLError, TimeoutError, OSError) as exc:
                last_error = exc
                if attempt + 1 < 4:
                    time.sleep(2**attempt)
        raise RegionalDownloadError(
            f"Pobieranie PBF przerwano po czterech próbach: {last_error}"
        )

    def _expected_md5(self, url):
        try:
            text = self._fetch_bytes(url + ".md5", attempts=2).decode(
                "ascii", errors="replace"
            )
        except RegionalDownloadError:
            return ""
        match = re.search(r"\b([0-9a-fA-F]{32})\b", text)
        return match.group(1).lower() if match else ""


def select_smallest_extract(catalogue, bbox):
    """Return the smallest Geofabrik polygon containing all bbox corners."""
    west, south, east, north = bbox
    corners = (
        (west, south),
        (west, north),
        (east, south),
        (east, north),
    )
    matches = []
    for feature in catalogue.get("features", []):
        properties = feature.get("properties") or {}
        if not (properties.get("urls") or {}).get("pbf"):
            continue
        geometry_json = feature.get("geometry")
        if not geometry_json:
            continue
        if not all(point_in_geojson(point, geometry_json) for point in corners):
            continue
        coordinates = list(iter_coordinates(geometry_json.get("coordinates", [])))
        xs = [coordinate[0] for coordinate in coordinates]
        ys = [coordinate[1] for coordinate in coordinates]
        envelope_area = (max(xs) - min(xs)) * (max(ys) - min(ys))
        matches.append((envelope_area, properties))
    if not matches:
        raise RegionalDownloadError(
            "Nie znaleziono wyciągu Geofabrik obejmującego całe zaznaczenie."
        )
    return min(matches, key=lambda item: item[0])[1]


def extract_to_gpkg(source_pbf, output_gpkg, bbox):
    """Use QGIS' bundled GDAL to spatially filter all styled OSM layers."""
    from qgis.core import QgsApplication

    source_pbf = Path(source_pbf)
    output_gpkg = Path(output_gpkg)
    output_gpkg.parent.mkdir(parents=True, exist_ok=True)
    executable_name = "ogr2ogr.exe" if os.name == "nt" else "ogr2ogr"
    prefix = Path(QgsApplication.prefixPath()) if QgsApplication.prefixPath() else None
    candidates = []
    if prefix is not None and len(prefix.parents) >= 2:
        candidates.append(prefix.resolve().parents[1])
    if len(Path(sys.executable).resolve().parents) >= 3:
        candidates.append(Path(sys.executable).resolve().parents[2])
    qgis_root = next(
        (root for root in candidates if (root / "bin" / executable_name).is_file()),
        candidates[0] if candidates else Path(),
    )
    ogr2ogr = qgis_root / "bin" / executable_name
    if not ogr2ogr.is_file():
        raise RegionalDownloadError(f"Nie znaleziono narzędzia GDAL: {ogr2ogr}")
    command = [
        str(ogr2ogr),
        "-f",
        "GPKG",
        str(output_gpkg),
        str(source_pbf),
        "points",
        "multilinestrings",
        "lines",
        "multipolygons",
        "-spat",
        *(str(value) for value in bbox),
        "-lco",
        "SPATIAL_INDEX=YES",
        "-overwrite",
    ]
    process_environment = os.environ.copy()
    process_environment.setdefault(
        "GDAL_DATA", str(qgis_root / "apps" / "gdal" / "share" / "gdal")
    )
    process_environment.setdefault("PROJ_LIB", str(qgis_root / "share" / "proj"))
    completed = subprocess.run(
        command,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        env=process_environment,
        check=False,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    )
    if completed.returncode:
        detail = (completed.stderr or completed.stdout).strip()
        raise RegionalDownloadError(f"GDAL nie utworzył wyciągu: {detail}")


def point_in_geojson(point, geometry):
    geometry_type = geometry.get("type")
    coordinates = geometry.get("coordinates") or []
    polygons = [coordinates] if geometry_type == "Polygon" else coordinates
    if geometry_type not in {"Polygon", "MultiPolygon"}:
        return False
    return any(point_in_polygon(point, polygon) for polygon in polygons)


def point_in_polygon(point, rings):
    if not rings or not point_in_ring(point, rings[0]):
        return False
    return not any(point_in_ring(point, hole) for hole in rings[1:])


def point_in_ring(point, ring):
    x, y = point
    inside = False
    previous_x, previous_y = ring[-1]
    for current_x, current_y in ring:
        crosses = (current_y > y) != (previous_y > y)
        if crosses:
            intersection_x = (previous_x - current_x) * (y - current_y) / (
                previous_y - current_y
            ) + current_x
            if x <= intersection_x:
                inside = not inside
        previous_x, previous_y = current_x, current_y
    return inside


def iter_coordinates(value):
    if value and isinstance(value[0], (int, float)):
        yield value
        return
    for child in value:
        yield from iter_coordinates(child)


def file_md5(path):
    digest = hashlib.md5()  # nosec B324 - verifies provider checksum, not security
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(CHUNK_SIZE), b""):
            digest.update(block)
    return digest.hexdigest().lower()


def strip_html(value):
    return re.sub(r"<[^>]+>", "", str(value)).strip()
