"""Download or load OSM data and apply bundled OpenStreetMap Carto styles."""

from pathlib import Path
from urllib.parse import urlencode

from qgis.PyQt.QtCore import QIODevice, QSaveFile, QSettings, Qt, QUrl
from qgis.PyQt.QtGui import QColor, QIcon
from qgis.PyQt.QtNetwork import QNetworkReply, QNetworkRequest
from qgis.PyQt.QtWidgets import (
    QAction,
    QApplication,
    QFileDialog,
    QProgressBar,
    QPushButton,
)
from qgis.core import (
    Qgis,
    QgsApplication,
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsNetworkAccessManager,
    QgsProject,
    QgsRectangle,
    QgsVectorLayer,
)

from .rectangle_area_tool import RectangleAreaTool
from .regional_download import RegionalPbfTask


PLUGIN_TITLE = "OSM Carto Downloader & Styler"
STYLE_VERSION = "0.2"
BACKGROUND_COLOR = "#F2EFE9"
OVERPASS_URL = "https://overpass-api.de/api/interpreter"

# The sequence is also the intended top-to-bottom order in QGIS.
LAYER_SPECS = (
    ("points", "Punkty i POI", "points.qml"),
    ("multilinestrings", "Relacje liniowe", "multilinestrings.qml"),
    ("lines", "Drogi, koleje i cieki", "lines.qml"),
    ("multipolygons", "Poligony", "multipolygons.qml"),
)


class PbfStyleLoaderPlugin:
    """QGIS Desktop plugin implementation."""

    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = Path(__file__).resolve().parent
        self.action = None
        self.download_action = None
        self.rectangle_tool = None
        self._download_reply = None
        self._download_file = None
        self._download_path = None
        self._download_widget = None
        self._download_progress = None
        self._download_cancelled = False
        self._regional_task = None

    def initGui(self):
        self.action = QAction(
            QIcon(str(self.plugin_dir / "icon-load-file.svg")),
            "Wczytaj lokalny PBF lub OSM ze stylem…",
            self.iface.mainWindow(),
        )
        self.action.setObjectName("osmCartoLoadFileAction")
        self.action.setStatusTip(
            "Dodaj warstwy lokalnego PBF lub OSM i zastosuj styl z ikonami SVG"
        )
        self.action.triggered.connect(self.choose_osm_file)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToVectorMenu(PLUGIN_TITLE, self.action)

        self.download_action = QAction(
            QIcon(str(self.plugin_dir / "icon-download-area.svg")),
            "Pobierz i wystylizuj OSM z prostokąta…",
            self.iface.mainWindow(),
        )
        self.download_action.setObjectName("pbfStyleLoaderDownloadAreaAction")
        self.download_action.setStatusTip(
            "Zaznacz prostokąt na mapie, pobierz dane OSM i zastosuj styl"
        )
        self.download_action.setCheckable(True)
        self.download_action.toggled.connect(self._toggle_rectangle_tool)
        self.iface.addToolBarIcon(self.download_action)
        self.iface.addPluginToVectorMenu(PLUGIN_TITLE, self.download_action)

    def unload(self):
        self._cancel_download(silent=True)
        if self.rectangle_tool is not None:
            self.rectangle_tool.reset()
            self.rectangle_tool = None
        for action in (self.action, self.download_action):
            if action is None:
                continue
            self.iface.removeToolBarIcon(action)
            self.iface.removePluginVectorMenu(PLUGIN_TITLE, action)
            action.deleteLater()
        self.action = None
        self.download_action = None

    def choose_osm_file(self):
        settings = QSettings()
        start_dir = settings.value(
            "osm_carto_downloader_styler/last_directory", "", type=str
        )
        pbf_path, _ = QFileDialog.getOpenFileName(
            self.iface.mainWindow(),
            "Wybierz plik OpenStreetMap PBF lub OSM",
            start_dir,
            "Dane OpenStreetMap (*.osm.pbf *.pbf *.osm *.gpkg);;Wszystkie pliki (*)",
        )
        if not pbf_path:
            return

        settings.setValue(
            "osm_carto_downloader_styler/last_directory",
            str(Path(pbf_path).resolve().parent),
        )
        self.load_osm_file(Path(pbf_path))

    def _toggle_rectangle_tool(self, enabled):
        """Activate or deactivate drawing the Overpass download rectangle."""
        canvas = self.iface.mapCanvas()
        if enabled:
            if self._download_reply is not None or self._regional_task is not None:
                self._critical("Najpierw poczekaj na zakończenie bieżącego pobierania.")
                self.download_action.setChecked(False)
                return
            if self.rectangle_tool is None:
                self.rectangle_tool = RectangleAreaTool(canvas, self.download_action)
                self.rectangle_tool.rectangleCreated.connect(
                    self._rectangle_selected
                )
            canvas.setMapTool(self.rectangle_tool)
        elif self.rectangle_tool is not None and canvas.mapTool() is self.rectangle_tool:
            canvas.unsetMapTool(self.rectangle_tool)

    def _rectangle_selected(self, rectangle):
        """Transform a canvas rectangle to WGS84 and ask where to save it."""
        if self.download_action is not None:
            self.download_action.setChecked(False)
        try:
            bbox = self._rectangle_to_wgs84(rectangle)
        except Exception as exc:
            self._critical(f"Nie można przeliczyć zaznaczenia do EPSG:4326: {exc}")
            return

        settings = QSettings()
        start_dir = settings.value(
            "osm_carto_downloader_styler/last_download_directory", "", type=str
        )
        suggested = (
            str(Path(start_dir) / "obszar-osm.gpkg")
            if start_dir
            else "obszar-osm.gpkg"
        )
        file_name, _ = QFileDialog.getSaveFileName(
            self.iface.mainWindow(),
            "Zapisz pobrane dane OpenStreetMap",
            suggested,
            "GeoPackage z danymi OpenStreetMap (*.gpkg)",
        )
        if not file_name:
            return
        output_path = Path(file_name)
        if output_path.suffix.lower() != ".gpkg":
            output_path = output_path.with_suffix(output_path.suffix + ".gpkg")
        settings.setValue(
            "osm_carto_downloader_styler/last_download_directory",
            str(output_path.resolve().parent),
        )
        self.download_regional_bbox(bbox, output_path)

    def download_regional_bbox(self, bbox, output_path):
        """Download a resumable regional PBF and extract the bbox locally."""
        if self._download_reply is not None or self._regional_task is not None:
            self._critical("Pobieranie danych jest już w toku.")
            return False
        cache_dir = (
            Path(QgsApplication.qgisSettingsDirPath())
            / "osm_carto_downloader_styler"
            / "cache"
        )
        task = RegionalPbfTask(
            (
                bbox.xMinimum(),
                bbox.yMinimum(),
                bbox.xMaximum(),
                bbox.yMaximum(),
            ),
            Path(output_path).resolve(),
            cache_dir,
            self._regional_download_finished,
        )
        self._regional_task = task
        self._show_download_progress()
        task.progressChanged.connect(self._update_task_progress)
        QgsApplication.taskManager().addTask(task)
        return True

    def _update_task_progress(self, progress):
        if self._download_progress is None:
            return
        self._download_progress.setRange(0, 1000)
        self._download_progress.setValue(int(progress * 10))
        self._download_progress.setFormat(f"{progress:.0f}%")

    def _regional_download_finished(self, success, task):
        if task is not self._regional_task:
            return
        output_path = task.output_path
        error_message = task.error_message
        region_name = task.region_name
        self._regional_task = None
        self._clear_download_state()
        if not success:
            if error_message and "anulowane" not in error_message.lower():
                self._critical(f"Nie udało się przygotować danych OSM: {error_message}")
            return
        self.iface.messageBar().pushSuccess(
            PLUGIN_TITLE,
            f"Przygotowano wyciąg z regionu {region_name}. Nakładanie stylu…",
        )
        self.load_osm_file(output_path)

    def _rectangle_to_wgs84(self, rectangle):
        source_crs = self.iface.mapCanvas().mapSettings().destinationCrs()
        if not source_crs.isValid():
            raise ValueError("bieżący CRS mapy jest nieprawidłowy")
        destination_crs = QgsCoordinateReferenceSystem("EPSG:4326")
        if source_crs == destination_crs:
            bbox = QgsRectangle(rectangle)
        else:
            transform = QgsCoordinateTransform(
                source_crs,
                destination_crs,
                QgsProject.instance().transformContext(),
            )
            bbox = transform.transformBoundingBox(rectangle)
        bbox.normalize()
        if bbox.isEmpty() or bbox.width() <= 0 or bbox.height() <= 0:
            raise ValueError("zaznaczony obszar jest pusty")
        if (
            bbox.xMinimum() < -180
            or bbox.xMaximum() > 180
            or bbox.yMinimum() < -90
            or bbox.yMaximum() > 90
        ):
            raise ValueError("zaznaczenie wykracza poza prawidłowy zakres WGS84")
        return bbox

    @staticmethod
    def overpass_query(bbox):
        """Build the complete OSM XML query for south, west, north, east."""
        south = bbox.yMinimum()
        west = bbox.xMinimum()
        north = bbox.yMaximum()
        east = bbox.xMaximum()
        return (
            "[out:xml][timeout:180];"
            "("
            f"node({south:.7f},{west:.7f},{north:.7f},{east:.7f});"
            f"way({south:.7f},{west:.7f},{north:.7f},{east:.7f});"
            f"relation({south:.7f},{west:.7f},{north:.7f},{east:.7f});"
            ");"
            "(._;>;);"
            "out meta;"
        )

    def download_bbox(self, bbox, output_path):
        """Download an OSM XML extract asynchronously through QGIS networking."""
        if self._download_reply is not None:
            self._critical("Pobieranie danych jest już w toku.")
            return False

        output_path = Path(output_path).resolve()
        try:
            output_path.parent.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            self._critical(f"Nie można przygotować katalogu wynikowego: {exc}")
            return False
        save_file = QSaveFile(str(output_path))
        if not save_file.open(QIODevice.WriteOnly):
            self._critical(f"Nie można zapisać pliku: {output_path}")
            return False

        query = self.overpass_query(bbox)
        payload = urlencode({"data": query}).encode("utf-8")
        request = QNetworkRequest(QUrl(OVERPASS_URL))
        request.setHeader(
            QNetworkRequest.ContentTypeHeader,
            "application/x-www-form-urlencoded; charset=UTF-8",
        )
        request.setRawHeader(
            b"User-Agent",
            b"OSM-Carto-Downloader-Styler/0.1 QGIS-Plugin",
        )

        self._download_path = output_path
        self._download_file = save_file
        self._download_cancelled = False
        self._download_prefix = bytearray()
        self._download_write_error = False
        self._show_download_progress()

        reply = QgsNetworkAccessManager.instance().post(request, payload)
        self._download_reply = reply
        reply.readyRead.connect(self._consume_download_data)
        reply.downloadProgress.connect(self._update_download_progress)
        reply.finished.connect(self._download_finished)
        return True

    def _show_download_progress(self):
        message_bar = self.iface.messageBar()
        widget = message_bar.createMessage("Pobieranie danych OpenStreetMap…")
        progress = QProgressBar()
        progress.setRange(0, 0)
        progress.setMinimumWidth(180)
        cancel_button = QPushButton("Anuluj")
        cancel_button.clicked.connect(self._cancel_download)
        widget.layout().addWidget(progress)
        widget.layout().addWidget(cancel_button)
        message_bar.pushWidget(widget, Qgis.MessageLevel.Info)
        self._download_widget = widget
        self._download_progress = progress

    def _consume_download_data(self):
        if self._download_reply is None or self._download_file is None:
            return
        data = bytes(self._download_reply.readAll())
        if not data:
            return
        if len(self._download_prefix) < 2048:
            remaining = 2048 - len(self._download_prefix)
            self._download_prefix.extend(data[:remaining])
        if self._download_file.write(data) != len(data):
            self._download_write_error = True
            self._download_reply.abort()

    def _update_download_progress(self, received, total):
        if self._download_progress is None:
            return
        if total > 0:
            self._download_progress.setRange(0, 1000)
            self._download_progress.setValue(min(1000, int(received * 1000 / total)))
            self._download_progress.setFormat(
                f"{received / 1_000_000:.1f} / {total / 1_000_000:.1f} MB"
            )
        else:
            self._download_progress.setRange(0, 0)

    def _cancel_download(self, _checked=False, silent=False):
        if self._regional_task is not None:
            self._download_cancelled = True
            self._regional_task.cancel()
            if not silent:
                self.iface.messageBar().pushWarning(
                    PLUGIN_TITLE,
                    "Anulowano pobieranie. Pobrana część pozostaje do wznowienia.",
                )
            return
        if self._download_reply is None:
            return
        self._download_cancelled = True
        self._download_reply.abort()
        if not silent:
            self.iface.messageBar().pushWarning(
                PLUGIN_TITLE, "Anulowano pobieranie danych OSM."
            )

    def _download_finished(self):
        reply = self._download_reply
        save_file = self._download_file
        output_path = self._download_path
        if reply is None or save_file is None:
            return
        self._consume_download_data()
        error = reply.error()
        error_text = reply.errorString()
        cancelled = self._download_cancelled
        write_error = self._download_write_error
        prefix = bytes(self._download_prefix).lower()

        success = (
            not cancelled
            and not write_error
            and error == QNetworkReply.NoError
            and b"<osm" in prefix
        )
        commit_failed = False
        if success:
            success = save_file.commit()
            commit_failed = not success
        else:
            save_file.cancelWriting()

        self._clear_download_state()
        reply.deleteLater()

        if not success:
            if not cancelled:
                if write_error:
                    message = "Błąd zapisu pobieranych danych."
                elif commit_failed:
                    message = "Nie można zatwierdzić wynikowego pliku OSM."
                elif error != QNetworkReply.NoError:
                    message = f"Błąd pobierania danych OSM: {error_text}"
                else:
                    message = "Serwer nie zwrócił prawidłowego pliku OSM XML."
                self._critical(message)
            return

        self.iface.messageBar().pushSuccess(
            PLUGIN_TITLE, f"Pobrano dane do {output_path.name}. Nakładanie stylu…"
        )
        self.load_osm_file(output_path)

    def _clear_download_state(self):
        if self._download_widget is not None:
            self.iface.messageBar().popWidget(self._download_widget)
        self._download_reply = None
        self._download_file = None
        self._download_path = None
        self._download_widget = None
        self._download_progress = None
        self._download_prefix = bytearray()
        self._download_write_error = False
        self._download_cancelled = False

    def load_pbf(self, pbf_path):
        """Backward-compatible entry point for a local PBF file."""
        return self.load_osm_file(pbf_path)

    def load_osm_file(self, source_path):
        """Load and style a local PBF, OSM XML or extracted GeoPackage."""
        source_path = Path(source_path).resolve()
        supported = source_path.suffix.lower() in {".pbf", ".osm", ".gpkg"}
        if not source_path.is_file() or not supported:
            self._critical(
                "Wskazany plik nie istnieje albo ma nieobsługiwany format."
            )
            return False

        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            layers, errors = self.create_styled_layers(source_path)
            if errors:
                self._critical(
                    "Nie udało się przygotować wszystkich warstw:\n• "
                    + "\n• ".join(errors)
                )
                return False

            project = QgsProject.instance()
            group = project.layerTreeRoot().insertGroup(
                0, self._unique_group_name(project, source_path)
            )
            for layer in layers:
                project.addMapLayer(layer, False)
                group.addLayer(layer)

            self._set_canvas_background()
            self._zoom_to_layers(layers)
            self.iface.messageBar().pushSuccess(
                PLUGIN_TITLE,
                f"Wczytano {len(layers)} warstwy z {source_path.name}.",
            )
            return True
        except Exception as exc:  # keep QGIS responsive and report plugin errors
            self._critical(f"Nieoczekiwany błąd podczas wczytywania danych OSM: {exc}")
            return False
        finally:
            QApplication.restoreOverrideCursor()

    def create_styled_layers(self, pbf_path):
        """Create styled layers without adding them to QgsProject.

        This separate method is intentionally testable in a headless QGIS
        process and avoids leaving a half-created group after an error.
        """
        pbf_path = Path(pbf_path).resolve()
        style_dir = self.plugin_dir / "Styles_PBF"
        layers = []
        errors = []

        for ogr_name, display_name, qml_name in LAYER_SPECS:
            source = f"{pbf_path}|layername={ogr_name}"
            layer = QgsVectorLayer(
                source,
                f"{display_name} — {pbf_path.stem}",
                "ogr",
            )
            if not layer.isValid():
                errors.append(f"{ogr_name}: warstwa OGR jest nieprawidłowa")
                continue

            qml_path = style_dir / qml_name
            if not qml_path.is_file():
                errors.append(f"{ogr_name}: brak stylu {qml_name}")
                continue

            message, success = layer.loadNamedStyle(str(qml_path))
            if not success:
                errors.append(f"{ogr_name}: nie można wczytać QML ({message})")
                continue

            missing_svg = self._make_svg_paths_absolute(layer, qml_path.parent)
            if missing_svg:
                errors.append(
                    f"{ogr_name}: nie znaleziono ikon SVG: "
                    + ", ".join(sorted(missing_svg))
                )
                continue

            layer.setCustomProperty("pbf_style_loader/style_version", STYLE_VERSION)
            layer.setCustomProperty("pbf_style_loader/source_pbf", str(pbf_path))
            layer.setCustomProperty("osm_carto_downloader/source_file", str(pbf_path))
            layer.triggerRepaint()
            layers.append(layer)

        if errors:
            # Dropping the references releases any successfully opened but
            # unused GDAL/OGR layers when the method returns.
            layers = []
        return layers, errors

    def _make_svg_paths_absolute(self, layer, style_dir):
        """Resolve bundled SVG paths against the installed plugin directory.

        QGIS may interpret paths stored in a loaded QML against the current
        project instead of the QML file.  Replacing them with verified,
        absolute paths makes rendering independent of the project location.
        """
        missing = set()
        root_rule = layer.renderer().rootRule()
        stack = list(root_rule.children())
        while stack:
            rule = stack.pop()
            if rule.children():
                stack.extend(rule.children())
            symbol = rule.symbol()
            if symbol is None:
                continue
            for index in range(symbol.symbolLayerCount()):
                symbol_layer = symbol.symbolLayer(index)
                if symbol_layer.layerType() != "SvgMarker":
                    continue
                raw_path = symbol_layer.path()
                resolved = self._resolve_svg_path(raw_path, style_dir)
                if resolved is None:
                    missing.add(raw_path or "(pusta ścieżka)")
                else:
                    # QgsSvgMarkerSymbolLayer.setPath() reloads the SVG and may
                    # reset param(fill) / param(stroke) to the file defaults.
                    # Preserve the colours saved in QML before replacing the
                    # relative path with the verified absolute one.
                    properties = symbol_layer.properties()
                    fill = self._serialized_color(properties.get("color"))
                    stroke = self._serialized_color(
                        properties.get("outline_color")
                    )
                    symbol_layer.setPath(str(resolved))
                    if fill is not None:
                        symbol_layer.setColor(fill)
                    if stroke is not None:
                        symbol_layer.setStrokeColor(stroke)
        return missing

    @staticmethod
    def _serialized_color(value):
        """Read QGIS' ``r,g,b,a,...`` colour serialization."""
        try:
            channels = [int(part) for part in str(value).split(",")[:4]]
        except (TypeError, ValueError):
            return None
        if len(channels) != 4:
            return None
        return QColor(*channels)

    def _resolve_svg_path(self, raw_path, style_dir):
        normalized = str(raw_path).replace("\\", "/")
        path = Path(normalized)
        candidates = []
        if path.is_absolute():
            candidates.append(path)
        else:
            candidates.append((Path(style_dir) / path).resolve())

        marker = "Symbols_PBF/"
        marker_index = normalized.find(marker)
        if marker_index >= 0:
            relative_icon = normalized[marker_index + len(marker):]
            candidates.append(
                (self.plugin_dir / "Symbols_PBF" / relative_icon).resolve()
            )

        for candidate in candidates:
            if candidate.is_file():
                return candidate
        return None

    def _unique_group_name(self, project, pbf_path):
        base = f"OSM Carto {STYLE_VERSION} — {self._dataset_name(pbf_path)}"
        names = {child.name() for child in project.layerTreeRoot().children()}
        if base not in names:
            return base
        index = 2
        while f"{base} ({index})" in names:
            index += 1
        return f"{base} ({index})"

    @staticmethod
    def _dataset_name(pbf_path):
        name = Path(pbf_path).name
        if name.lower().endswith(".osm.pbf"):
            return name[:-8]
        return Path(name).stem

    def _set_canvas_background(self):
        color = QColor(BACKGROUND_COLOR)
        self.iface.mapCanvas().setCanvasColor(color)
        project = QgsProject.instance()
        if hasattr(project, "setBackgroundColor"):
            project.setBackgroundColor(color)

    def _zoom_to_layers(self, layers):
        """Fit and explicitly center the canvas on the loaded PBF data.

        Layer extents are expressed in the layer CRS, while ``setExtent``
        expects coordinates in the current map canvas CRS.  Transforming each
        extent before combining them keeps centering correct in existing
        projects which use a CRS other than the PBF layer CRS.
        """
        canvas = self.iface.mapCanvas()
        project = QgsProject.instance()
        destination_crs = canvas.mapSettings().destinationCrs()
        combined = None
        for layer in layers:
            extent = layer.extent()
            if extent.isEmpty():
                continue
            source_crs = layer.crs()
            if (
                source_crs.isValid()
                and destination_crs.isValid()
                and source_crs != destination_crs
            ):
                transform = QgsCoordinateTransform(
                    source_crs,
                    destination_crs,
                    project.transformContext(),
                )
                extent = transform.transformBoundingBox(extent)
            if combined is None:
                combined = QgsRectangle(extent)
            else:
                combined.combineExtentWith(extent)
        if combined is not None and not combined.isEmpty():
            canvas.setExtent(combined)
            canvas.setCenter(combined.center())
        canvas.refresh()

    def _critical(self, message):
        self.iface.messageBar().pushCritical(PLUGIN_TITLE, message)
