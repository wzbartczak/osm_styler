<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis simplifyLocal="1" styleCategories="AllStyleCategories" labelsEnabled="1" autoRefreshMode="Disabled" version="3.40.12-Bratislava" maxScale="0" hasScaleBasedVisibilityFlag="0" simplifyAlgorithm="0" simplifyMaxScale="1" symbologyReferenceScale="-1" simplifyDrawingTol="1" minScale="100000000" readOnly="0" autoRefreshTime="0" simplifyDrawingHints="1">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal durationField="" fixedDuration="0" endExpression="" accumulate="0" durationUnit="min" startField="" startExpression="" enabled="0" mode="0" endField="" limitMode="0">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation symbology="Line" respectLayerSymbol="1" zscale="1" extrusionEnabled="0" binding="Centroid" type="IndividualFeatures" showMarkerSymbolInSurfacePlots="0" zoffset="0" extrusion="0" clamping="Terrain">
    <data-defined-properties>
      <Option type="Map">
        <Option value="" name="name" type="QString"/>
        <Option name="properties"/>
        <Option value="collection" name="type" type="QString"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol name="" clip_to_extent="1" alpha="1" force_rhr="0" type="line" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="0" class="SimpleLine" locked="0" enabled="1" id="{20fe3aed-98a5-48d7-83fe-2b067c9c31b4}">
          <Option type="Map">
            <Option value="0" name="align_dash_pattern" type="QString"/>
            <Option value="square" name="capstyle" type="QString"/>
            <Option value="5;2" name="customdash" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale" type="QString"/>
            <Option value="MM" name="customdash_unit" type="QString"/>
            <Option value="0" name="dash_pattern_offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="dash_pattern_offset_unit" type="QString"/>
            <Option value="0" name="draw_inside_polygon" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="196,60,57,255,rgb:0.7686274509803922,0.23529411764705882,0.22352941176470589,1" name="line_color" type="QString"/>
            <Option value="solid" name="line_style" type="QString"/>
            <Option value="0.6" name="line_width" type="QString"/>
            <Option value="MM" name="line_width_unit" type="QString"/>
            <Option value="0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="0" name="ring_filter" type="QString"/>
            <Option value="0" name="trim_distance_end" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale" type="QString"/>
            <Option value="MM" name="trim_distance_end_unit" type="QString"/>
            <Option value="0" name="trim_distance_start" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale" type="QString"/>
            <Option value="MM" name="trim_distance_start_unit" type="QString"/>
            <Option value="0" name="tweak_dash_pattern_on_corners" type="QString"/>
            <Option value="0" name="use_custom_dash" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="width_map_unit_scale" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol name="" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="0" class="SimpleFill" locked="0" enabled="1" id="{3dac0421-59f4-4ff0-b379-c7e3de127d64}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="196,60,57,255,rgb:0.7686274509803922,0.23529411764705882,0.22352941176470589,1" name="color" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="140,43,41,255,rgb:0.5490196078431373,0.16803234912642101,0.15967040512703135,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.2" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol name="" clip_to_extent="1" alpha="1" force_rhr="0" type="marker" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="0" class="SimpleMarker" locked="0" enabled="1" id="{8330c008-b98f-4dde-9c54-3eb73b74959b}">
          <Option type="Map">
            <Option value="0" name="angle" type="QString"/>
            <Option value="square" name="cap_style" type="QString"/>
            <Option value="196,60,57,255,rgb:0.7686274509803922,0.23529411764705882,0.22352941176470589,1" name="color" type="QString"/>
            <Option value="1" name="horizontal_anchor_point" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="diamond" name="name" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="140,43,41,255,rgb:0.5490196078431373,0.16803234912642101,0.15967040512703135,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.2" name="outline_width" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="diameter" name="scale_method" type="QString"/>
            <Option value="3" name="size" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
            <Option value="MM" name="size_unit" type="QString"/>
            <Option value="1" name="vertical_anchor_point" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 symbollevels="1" forceraster="0" enableorderby="0" referencescale="-1" type="RuleRenderer">
    <rules key="{18a16614-2cb1-4350-a370-bbc60c9def6a}">
      <rule label="Granice państwowe" key="{e8a4d799-8231-46e3-99c7-065f6c5857da}" filter="(coalesce(&quot;man_made&quot;, '') != 'bridge' AND coalesce(map_get(hstore_to_map(&quot;other_tags&quot;), 'bridge'), 'no') IN ('no','')) AND (&quot;boundary&quot; = 'administrative' AND &quot;admin_level&quot; = '2')">
        <rule label="z2-z15" scalemaxdenom="139770566" symbol="0" key="{79edc2a8-6bb4-4750-bc8b-9372152ecad9}" scalemindenom="8531"/>
        <rule label="z16-z17" scalemaxdenom="8531" symbol="1" key="{19c8cfbf-0cf6-49b3-bfce-f33d53c1d01c}" scalemindenom="2133"/>
        <rule label="z18-z19" scalemaxdenom="2133" symbol="2" key="{a0204327-0975-4812-8fb2-faa08c2f5f85}" scalemindenom="533"/>
        <rule label="z20+" scalemaxdenom="533" symbol="3" key="{8bab4a2c-f121-4c18-9da7-01790c5dc558}"/>
      </rule>
      <rule label="Granice regionalne" key="{938ae93b-7cf0-4d14-bf76-e3b042eefdcf}" filter="(coalesce(&quot;man_made&quot;, '') != 'bridge' AND coalesce(map_get(hstore_to_map(&quot;other_tags&quot;), 'bridge'), 'no') IN ('no','')) AND (&quot;boundary&quot; = 'administrative' AND &quot;admin_level&quot; IN ('3','4','5','6'))">
        <rule label="z5-z15" scalemaxdenom="17471321" symbol="4" key="{6c37aaff-994f-4581-ad3d-f5bc8befd726}" scalemindenom="8531"/>
        <rule label="z16-z17" scalemaxdenom="8531" symbol="5" key="{715d02fc-4a17-419c-a063-3e8f5ebd9423}" scalemindenom="2133"/>
        <rule label="z18-z19" scalemaxdenom="2133" symbol="6" key="{8c75574e-11b1-49cc-97d8-3f99eb925930}" scalemindenom="533"/>
        <rule label="z20+" scalemaxdenom="533" symbol="7" key="{7fc3ac11-6631-430b-b362-b7190f8a823a}"/>
      </rule>
      <rule label="Granice lokalne" key="{6fe1d241-6b8d-4500-a470-562619f4bcd7}" filter="(coalesce(&quot;man_made&quot;, '') != 'bridge' AND coalesce(map_get(hstore_to_map(&quot;other_tags&quot;), 'bridge'), 'no') IN ('no','')) AND (&quot;boundary&quot; = 'administrative' AND &quot;admin_level&quot; IN ('7','8','9','10','11'))">
        <rule label="z9-z15" scalemaxdenom="1091958" symbol="8" key="{07d44bc5-738f-45f0-9d30-e055ae381e3e}" scalemindenom="8531"/>
        <rule label="z16-z17" scalemaxdenom="8531" symbol="9" key="{1d01e466-f89d-4b56-8a3e-649cdc3a15d2}" scalemindenom="2133"/>
        <rule label="z18-z19" scalemaxdenom="2133" symbol="10" key="{136b1ba8-a64e-4fe1-91cb-a445e600b63c}" scalemindenom="533"/>
        <rule label="z20+" scalemaxdenom="533" symbol="11" key="{7bbe091b-cf67-4a25-8532-615ae7a675f6}"/>
      </rule>
      <rule label="Woda powierzchniowa" key="{20998a6a-6755-4b25-9d06-79c537821960}" filter="(coalesce(&quot;man_made&quot;, '') != 'bridge' AND coalesce(map_get(hstore_to_map(&quot;other_tags&quot;), 'bridge'), 'no') IN ('no','')) AND ((&quot;building&quot; IS NULL OR &quot;building&quot; = '') AND (&quot;natural&quot; = 'water' OR &quot;landuse&quot; IN ('reservoir','basin') OR map_get(hstore_to_map(&quot;other_tags&quot;), 'waterway') = 'dock'))">
        <rule label="z5-z15" scalemaxdenom="17471321" symbol="12" key="{332e2f55-c490-46a4-8faf-7564f7b2a37f}" scalemindenom="8531"/>
        <rule label="z16-z17" scalemaxdenom="8531" symbol="13" key="{ec13fb47-8be5-49b5-8012-7967261ac7f1}" scalemindenom="2133"/>
        <rule label="z18-z19" scalemaxdenom="2133" symbol="14" key="{360e8a88-e08a-4ca2-84e3-cf9e45ed009d}" scalemindenom="533"/>
        <rule label="z20+" scalemaxdenom="533" symbol="15" key="{86132943-3486-4f42-b595-b9740c222a08}"/>
      </rule>
      <rule label="Lasy" key="{6ec24b07-3811-48c7-ab8e-eb3060fe6252}" filter="(coalesce(&quot;man_made&quot;, '') != 'bridge' AND coalesce(map_get(hstore_to_map(&quot;other_tags&quot;), 'bridge'), 'no') IN ('no','')) AND ((&quot;building&quot; IS NULL OR &quot;building&quot; = '') AND (&quot;landuse&quot; = 'forest' OR &quot;natural&quot; = 'wood'))">
        <rule label="z5-z15" scalemaxdenom="17471321" symbol="16" key="{f28d661d-8d96-4fde-ac21-6e754091dae3}" scalemindenom="8531"/>
        <rule label="z16-z17" scalemaxdenom="8531" symbol="17" key="{fad56bf9-61e5-490b-a6b9-df8d404d008b}" scalemindenom="2133"/>
        <rule label="z18-z19" scalemaxdenom="2133" symbol="18" key="{ff0ef1ec-1c7e-4c55-be09-776438aadd70}" scalemindenom="533"/>
        <rule label="z20+" scalemaxdenom="533" symbol="19" key="{61c343e3-ade9-4f70-899c-11ef99770415}"/>
      </rule>
      <rule label="Grunty rolne" key="{ebe0d158-e938-4530-b817-89c7211ccf2f}" filter="(coalesce(&quot;man_made&quot;, '') != 'bridge' AND coalesce(map_get(hstore_to_map(&quot;other_tags&quot;), 'bridge'), 'no') IN ('no','')) AND ((&quot;building&quot; IS NULL OR &quot;building&quot; = '') AND (&quot;landuse&quot; IN ('farmland','greenhouse_horticulture')))">
        <rule label="z5-z15" scalemaxdenom="17471321" symbol="20" key="{20883be1-20ee-496e-9691-2a105f425b95}" scalemindenom="8531"/>
        <rule label="z16-z17" scalemaxdenom="8531" symbol="21" key="{43e7143d-d16d-4f73-b064-fdf2283f52bd}" scalemindenom="2133"/>
        <rule label="z18-z19" scalemaxdenom="2133" symbol="22" key="{220518d3-851b-4eb0-bc3d-57965c3b0bd0}" scalemindenom="533"/>
        <rule label="z20+" scalemaxdenom="533" symbol="23" key="{86cfddf7-b6c4-440e-94eb-bdc14c8a3f5d}"/>
      </rule>
      <rule label="Zagrody" key="{301d1cf3-f082-483c-adbd-68e742b74212}" filter="(coalesce(&quot;man_made&quot;, '') != 'bridge' AND coalesce(map_get(hstore_to_map(&quot;other_tags&quot;), 'bridge'), 'no') IN ('no','')) AND ((&quot;building&quot; IS NULL OR &quot;building&quot; = '') AND (&quot;landuse&quot; = 'farmyard'))">
        <rule label="z10-z15" scalemaxdenom="545979" symbol="24" key="{8a730987-6adf-47a2-a314-248eec2656ed}" scalemindenom="8531"/>
        <rule label="z16-z17" scalemaxdenom="8531" symbol="25" key="{a1eee91b-2996-4edc-a15e-1c02dbd5d186}" scalemindenom="2133"/>
        <rule label="z18-z19" scalemaxdenom="2133" symbol="26" key="{a09cd530-eba4-498e-a060-984af26b14fe}" scalemindenom="533"/>
        <rule label="z20+" scalemaxdenom="533" symbol="27" key="{c19d9f61-1bf7-4c95-b255-8d7a18a8f8f1}"/>
      </rule>
      <rule label="Łąki i trawy" key="{7f60f2ca-59fd-47d7-afef-ab8751beec0e}" filter="(coalesce(&quot;man_made&quot;, '') != 'bridge' AND coalesce(map_get(hstore_to_map(&quot;other_tags&quot;), 'bridge'), 'no') IN ('no','')) AND ((&quot;building&quot; IS NULL OR &quot;building&quot; = '') AND (&quot;natural&quot; = 'grassland' OR &quot;landuse&quot; IN ('meadow','grass','village_green')))">
        <rule label="z5-z15" scalemaxdenom="17471321" symbol="28" key="{31b319f9-8251-40a6-9ddc-780646b618dd}" scalemindenom="8531"/>
        <rule label="z16-z17" scalemaxdenom="8531" symbol="29" key="{ba521e80-a685-4ed7-a6ed-f4cc9bd99f51}" scalemindenom="2133"/>
        <rule label="z18-z19" scalemaxdenom="2133" symbol="30" key="{dd0c9cff-4748-4f11-9ddd-c347a5cdb543}" scalemindenom="533"/>
        <rule label="z20+" scalemaxdenom="533" symbol="31" key="{d5e61c16-c82c-4d0b-b16b-08bef3d5ec62}"/>
      </rule>
      <rule label="Ogrody działkowe" key="{4cda177a-5d9e-42f2-bb22-a10da2f11c51}" filter="(coalesce(&quot;man_made&quot;, '') != 'bridge' AND coalesce(map_get(hstore_to_map(&quot;other_tags&quot;), 'bridge'), 'no') IN ('no','')) AND ((&quot;building&quot; IS NULL OR &quot;building&quot; = '') AND (&quot;landuse&quot; = 'allotments'))">
        <rule label="z10-z15" scalemaxdenom="545979" symbol="32" key="{20eda55e-0b48-48d9-b9fc-8cfdf5f858ea}" scalemindenom="8531"/>
        <rule label="z16-z17" scalemaxdenom="8531" symbol="33" key="{c0021beb-89e4-4142-b95e-7f96b1ab8622}" scalemindenom="2133"/>
        <rule label="z18-z19" scalemaxdenom="2133" symbol="34" key="{74467ad1-341b-4dc0-9d47-d786e840b997}" scalemindenom="533"/>
        <rule label="z20+" scalemaxdenom="533" symbol="35" key="{109440b0-2246-416c-8dc9-6f68eb193f82}"/>
      </rule>
      <rule label="Sady" key="{1a3e64be-8705-4e80-8f0f-43b65ec3f0f7}" filter="(coalesce(&quot;man_made&quot;, '') != 'bridge' AND coalesce(map_get(hstore_to_map(&quot;other_tags&quot;), 'bridge'), 'no') IN ('no','')) AND ((&quot;building&quot; IS NULL OR &quot;building&quot; = '') AND (&quot;landuse&quot; = 'orchard'))">
        <rule label="z5-z15" scalemaxdenom="17471321" symbol="36" key="{510a843f-17df-4bfa-9ef9-496e58095a1a}" scalemindenom="8531"/>
        <rule label="z16-z17" scalemaxdenom="8531" symbol="37" key="{51a799a7-e70f-4953-b5d1-d1ce69cd1d7a}" scalemindenom="2133"/>
        <rule label="z18-z19" scalemaxdenom="2133" symbol="38" key="{0b2d47da-0c1d-4781-a49b-511c0fc86fcb}" scalemindenom="533"/>
        <rule label="z20+" scalemaxdenom="533" symbol="39" key="{062b7961-f63d-44e1-b380-3627ee6607af}"/>
      </rule>
      <rule label="Winnice" key="{84d6d12a-6458-4437-846a-fe5f5b1d4818}" filter="(coalesce(&quot;man_made&quot;, '') != 'bridge' AND coalesce(map_get(hstore_to_map(&quot;other_tags&quot;), 'bridge'), 'no') IN ('no','')) AND ((&quot;building&quot; IS NULL OR &quot;building&quot; = '') AND (&quot;landuse&quot; = 'vineyard'))">
        <rule label="z5-z15" scalemaxdenom="17471321" symbol="40" key="{432bd291-69fe-49df-80a9-d0198860df61}" scalemindenom="8531"/>
        <rule label="z16-z17" scalemaxdenom="8531" symbol="41" key="{517c8deb-3afc-46ac-8625-6c9250d53d40}" scalemindenom="2133"/>
        <rule label="z18-z19" scalemaxdenom="2133" symbol="42" key="{343ef607-bbbb-4d8e-8671-1a00e14e8505}" scalemindenom="533"/>
        <rule label="z20+" scalemaxdenom="533" symbol="43" key="{8af6d8e1-d601-4eb5-b3fd-67a5d0208ad0}"/>
      </rule>
      <rule label="Parki" key="{46244679-452a-4c19-93b5-887356816f5d}" filter="(coalesce(&quot;man_made&quot;, '') != 'bridge' AND coalesce(map_get(hstore_to_map(&quot;other_tags&quot;), 'bridge'), 'no') IN ('no','')) AND ((&quot;building&quot; IS NULL OR &quot;building&quot; = '') AND (&quot;leisure&quot; = 'park'))">
        <rule label="z10-z15" scalemaxdenom="545979" symbol="44" key="{dd46329e-65d9-406d-9ef5-54901d1f23e2}" scalemindenom="8531"/>
        <rule label="z16-z17" scalemaxdenom="8531" symbol="45" key="{240481e6-b61e-4431-8b7b-27f1580a13f4}" scalemindenom="2133"/>
        <rule label="z18-z19" scalemaxdenom="2133" symbol="46" key="{57070fe8-d01b-46e6-af45-99e60f112f9c}" scalemindenom="533"/>
        <rule label="z20+" scalemaxdenom="533" symbol="47" key="{22b9e087-5f53-4891-ada9-ea81b1a146b9}"/>
      </rule>
      <rule label="Tereny rekreacyjne" key="{701cd992-da28-4b52-8d1c-e2cdf568b7c5}" filter="(coalesce(&quot;man_made&quot;, '') != 'bridge' AND coalesce(map_get(hstore_to_map(&quot;other_tags&quot;), 'bridge'), 'no') IN ('no','')) AND ((&quot;building&quot; IS NULL OR &quot;building&quot; = '') AND (&quot;landuse&quot; = 'recreation_ground' OR &quot;leisure&quot; IN ('playground','fitness_station')))">
        <rule label="z10-z15" scalemaxdenom="545979" symbol="48" key="{aa5a6076-d704-42bd-b111-3157c9e8ab21}" scalemindenom="8531"/>
        <rule label="z16-z17" scalemaxdenom="8531" symbol="49" key="{8ee751ad-692a-4d3d-ba70-91fa5cd507da}" scalemindenom="2133"/>
        <rule label="z18-z19" scalemaxdenom="2133" symbol="50" key="{b51c4bc1-7970-4fd4-a28a-26c90aa52011}" scalemindenom="533"/>
        <rule label="z20+" scalemaxdenom="533" symbol="51" key="{5eea9c9f-f452-4428-a506-bff0c2e43838}"/>
      </rule>
      <rule label="Rezerwaty przyrody" key="{494ddd25-c5c5-4d4d-829d-687e04855eb8}" filter="(coalesce(&quot;man_made&quot;, '') != 'bridge' AND coalesce(map_get(hstore_to_map(&quot;other_tags&quot;), 'bridge'), 'no') IN ('no','')) AND ((&quot;building&quot; IS NULL OR &quot;building&quot; = '') AND (&quot;leisure&quot; = 'nature_reserve' OR &quot;boundary&quot; = 'protected_area'))">
        <rule label="z7-z15" scalemaxdenom="4367830" symbol="52" key="{bf9c7dda-401e-436f-9c3f-2a335cd4e7dc}" scalemindenom="8531"/>
        <rule label="z16-z17" scalemaxdenom="8531" symbol="53" key="{ce28f78d-cfb4-4012-9030-e8f33b436780}" scalemindenom="2133"/>
        <rule label="z18-z19" scalemaxdenom="2133" symbol="54" key="{78c29d05-93ba-4e87-b194-e4f910b99e33}" scalemindenom="533"/>
        <rule label="z20+" scalemaxdenom="533" symbol="55" key="{5732ccf6-dda3-4c95-8cba-032ec4826841}"/>
      </rule>
      <rule label="Tereny mieszkaniowe" key="{5a2222d6-4093-4659-a708-302ddd37dfad}" filter="(coalesce(&quot;man_made&quot;, '') != 'bridge' AND coalesce(map_get(hstore_to_map(&quot;other_tags&quot;), 'bridge'), 'no') IN ('no','')) AND ((&quot;building&quot; IS NULL OR &quot;building&quot; = '') AND (&quot;landuse&quot; = 'residential'))">
        <rule label="z8-z15" scalemaxdenom="2183915" symbol="56" key="{2eb304b0-d332-4881-8d1d-add3b88a1081}" scalemindenom="8531"/>
        <rule label="z16-z17" scalemaxdenom="8531" symbol="57" key="{93b8503b-758b-4b12-b988-acca2b5a6353}" scalemindenom="2133"/>
        <rule label="z18-z19" scalemaxdenom="2133" symbol="58" key="{bb9ada94-ba53-4100-abd0-c6976349ba8e}" scalemindenom="533"/>
        <rule label="z20+" scalemaxdenom="533" symbol="59" key="{60b7c774-66db-482e-b68a-a0a1230d8323}"/>
      </rule>
      <rule label="Handel detaliczny" key="{46bc4fcf-437d-4bfc-bc9d-314028a6007d}" filter="(coalesce(&quot;man_made&quot;, '') != 'bridge' AND coalesce(map_get(hstore_to_map(&quot;other_tags&quot;), 'bridge'), 'no') IN ('no','')) AND ((&quot;building&quot; IS NULL OR &quot;building&quot; = '') AND (&quot;landuse&quot; = 'retail' OR &quot;shop&quot; = 'mall' OR &quot;amenity&quot; = 'marketplace'))">
        <rule label="z8-z15" scalemaxdenom="2183915" symbol="60" key="{9d58da9a-4615-4a28-9cd3-efd2c41b2c0f}" scalemindenom="8531"/>
        <rule label="z16-z17" scalemaxdenom="8531" symbol="61" key="{1593bdc0-5825-46d8-8151-befc0cbea0ad}" scalemindenom="2133"/>
        <rule label="z18-z19" scalemaxdenom="2133" symbol="62" key="{d234de3d-32ab-4f6a-9db5-04c05ec37fdc}" scalemindenom="533"/>
        <rule label="z20+" scalemaxdenom="533" symbol="63" key="{71090387-bf7c-4a6b-b10e-9c144ba54f41}"/>
      </rule>
      <rule label="Tereny komercyjne" key="{7351361c-7768-468d-9a92-d2ebbe4e7008}" filter="(coalesce(&quot;man_made&quot;, '') != 'bridge' AND coalesce(map_get(hstore_to_map(&quot;other_tags&quot;), 'bridge'), 'no') IN ('no','')) AND ((&quot;building&quot; IS NULL OR &quot;building&quot; = '') AND (&quot;landuse&quot; = 'commercial'))">
        <rule label="z8-z15" scalemaxdenom="2183915" symbol="64" key="{83790647-5831-4a4a-991b-59982b94092c}" scalemindenom="8531"/>
        <rule label="z16-z17" scalemaxdenom="8531" symbol="65" key="{21af295f-024b-46f8-824d-8dfe93f0dabd}" scalemindenom="2133"/>
        <rule label="z18-z19" scalemaxdenom="2133" symbol="66" key="{4945b6de-e7fa-4e39-abc2-01add7b8e168}" scalemindenom="533"/>
        <rule label="z20+" scalemaxdenom="533" symbol="67" key="{ad5cf9e2-552c-4ffe-9ed2-ba5989558fe1}"/>
      </rule>
      <rule label="Tereny przemysłowe" key="{3a8910af-ab8f-4d4e-afa7-bf2a23aa2d77}" filter="(coalesce(&quot;man_made&quot;, '') != 'bridge' AND coalesce(map_get(hstore_to_map(&quot;other_tags&quot;), 'bridge'), 'no') IN ('no','')) AND ((&quot;building&quot; IS NULL OR &quot;building&quot; = '') AND (&quot;landuse&quot; = 'industrial'))">
        <rule label="z8-z15" scalemaxdenom="2183915" symbol="68" key="{215db48f-3f28-4fb5-838d-05d8a6020c67}" scalemindenom="8531"/>
        <rule label="z16-z17" scalemaxdenom="8531" symbol="69" key="{b3a07b48-04bc-4ff4-b9aa-5d070c291c53}" scalemindenom="2133"/>
        <rule label="z18-z19" scalemaxdenom="2133" symbol="70" key="{6480e9fd-a8d8-4c17-b0ef-a4188aedcf38}" scalemindenom="533"/>
        <rule label="z20+" scalemaxdenom="533" symbol="71" key="{2a1bb3a0-baf4-4e2a-bee7-258df69e7914}"/>
      </rule>
      <rule label="Tereny kolejowe" key="{c46fb6c9-0fe6-4016-b4ae-b18d574c412f}" filter="(coalesce(&quot;man_made&quot;, '') != 'bridge' AND coalesce(map_get(hstore_to_map(&quot;other_tags&quot;), 'bridge'), 'no') IN ('no','')) AND ((&quot;building&quot; IS NULL OR &quot;building&quot; = '') AND (&quot;landuse&quot; = 'railway'))">
        <rule label="z10-z15" scalemaxdenom="545979" symbol="72" key="{33c70e42-3e39-49f5-a24e-ce3b69ce4968}" scalemindenom="8531"/>
        <rule label="z16-z17" scalemaxdenom="8531" symbol="73" key="{6a3a3eac-fbdd-4e2b-88aa-c9b608aea2fb}" scalemindenom="2133"/>
        <rule label="z18-z19" scalemaxdenom="2133" symbol="74" key="{41d5df1f-621b-4d77-8cf9-9cd24e135259}" scalemindenom="533"/>
        <rule label="z20+" scalemaxdenom="533" symbol="75" key="{8ef4507e-4ed8-41a6-81d4-2f22873a6224}"/>
      </rule>
      <rule label="Cmentarze" key="{25c8f9be-3575-4e8c-8224-f8c370374ce6}" filter="(coalesce(&quot;man_made&quot;, '') != 'bridge' AND coalesce(map_get(hstore_to_map(&quot;other_tags&quot;), 'bridge'), 'no') IN ('no','')) AND ((&quot;building&quot; IS NULL OR &quot;building&quot; = '') AND (&quot;landuse&quot; = 'cemetery' OR &quot;amenity&quot; = 'grave_yard'))">
        <rule label="z10-z15" scalemaxdenom="545979" symbol="76" key="{919c897e-b6f0-4260-802b-b6b6b6001ed8}" scalemindenom="8531"/>
        <rule label="z16-z17" scalemaxdenom="8531" symbol="77" key="{7f3fb6a6-5914-4599-b4df-b8eca3627a3f}" scalemindenom="2133"/>
        <rule label="z18-z19" scalemaxdenom="2133" symbol="78" key="{85eaf810-4332-4568-b7ef-295f086fe97d}" scalemindenom="533"/>
        <rule label="z20+" scalemaxdenom="533" symbol="79" key="{1717c0de-1938-40a4-af2f-3e1bccd4c8a0}"/>
      </rule>
      <rule label="Obiekty wojskowe" key="{640738de-b05d-4cc4-abfd-69ec1468159d}" filter="(coalesce(&quot;man_made&quot;, '') != 'bridge' AND coalesce(map_get(hstore_to_map(&quot;other_tags&quot;), 'bridge'), 'no') IN ('no','')) AND ((&quot;building&quot; IS NULL OR &quot;building&quot; = '') AND (&quot;landuse&quot; = 'military' OR &quot;military&quot; IS NOT NULL))">
        <rule label="z8-z15" scalemaxdenom="2183915" symbol="80" key="{13ec151b-13a2-4a2b-9585-736c3f8e9807}" scalemindenom="8531"/>
        <rule label="z16-z17" scalemaxdenom="8531" symbol="81" key="{5f03526c-10cd-4757-aefc-291c25b9e02b}" scalemindenom="2133"/>
        <rule label="z18-z19" scalemaxdenom="2133" symbol="82" key="{3f78ddcf-8c5c-4941-9972-8f980b52407d}" scalemindenom="533"/>
        <rule label="z20+" scalemaxdenom="533" symbol="83" key="{16d48558-acea-4b94-b390-a68c3ba54c01}"/>
      </rule>
      <rule label="Plaże" key="{ebb819ca-bc18-454c-970c-74a2686c6ab8}" filter="(coalesce(&quot;man_made&quot;, '') != 'bridge' AND coalesce(map_get(hstore_to_map(&quot;other_tags&quot;), 'bridge'), 'no') IN ('no','')) AND ((&quot;building&quot; IS NULL OR &quot;building&quot; = '') AND (&quot;natural&quot; = 'beach'))">
        <rule label="z10-z15" scalemaxdenom="545979" symbol="84" key="{4d3921f8-6927-4995-b806-526a07cdfc46}" scalemindenom="8531"/>
        <rule label="z16-z17" scalemaxdenom="8531" symbol="85" key="{f4d0b60f-142c-4fd4-be51-1ccc51f2cc76}" scalemindenom="2133"/>
        <rule label="z18-z19" scalemaxdenom="2133" symbol="86" key="{2c4eb539-b5e9-4229-89a8-703d51504e5a}" scalemindenom="533"/>
        <rule label="z20+" scalemaxdenom="533" symbol="87" key="{bc3787fc-710b-46fa-9c18-ae80d730bad6}"/>
      </rule>
      <rule label="Piasek" key="{c6aa0843-5c0b-4535-9ea9-443b312133cd}" filter="(coalesce(&quot;man_made&quot;, '') != 'bridge' AND coalesce(map_get(hstore_to_map(&quot;other_tags&quot;), 'bridge'), 'no') IN ('no','')) AND ((&quot;building&quot; IS NULL OR &quot;building&quot; = '') AND (&quot;natural&quot; = 'sand'))">
        <rule label="z5-z15" scalemaxdenom="17471321" symbol="88" key="{c23f8e6d-11fe-4537-9fff-25ae43b3b580}" scalemindenom="8531"/>
        <rule label="z16-z17" scalemaxdenom="8531" symbol="89" key="{d06a675e-1b88-4309-a25c-0dc1ec0d283e}" scalemindenom="2133"/>
        <rule label="z18-z19" scalemaxdenom="2133" symbol="90" key="{2d679506-b746-4e66-9703-de4afd249a1e}" scalemindenom="533"/>
        <rule label="z20+" scalemaxdenom="533" symbol="91" key="{7576b299-1f90-4cf7-8155-cfd46c943814}"/>
      </rule>
      <rule label="Skały i piargi" key="{90652375-43f8-4719-b803-62cff1dc58fd}" filter="(coalesce(&quot;man_made&quot;, '') != 'bridge' AND coalesce(map_get(hstore_to_map(&quot;other_tags&quot;), 'bridge'), 'no') IN ('no','')) AND ((&quot;building&quot; IS NULL OR &quot;building&quot; = '') AND (&quot;natural&quot; IN ('bare_rock','scree','shingle')))">
        <rule label="z5-z15" scalemaxdenom="17471321" symbol="92" key="{e0ac2bc2-1484-419c-b10c-d2a4fe91e686}" scalemindenom="8531"/>
        <rule label="z16-z17" scalemaxdenom="8531" symbol="93" key="{499a84c0-47fe-4755-b2f6-ed3b5f5167c1}" scalemindenom="2133"/>
        <rule label="z18-z19" scalemaxdenom="2133" symbol="94" key="{e2173286-e5f9-4ac4-8fa4-0fef23b04e14}" scalemindenom="533"/>
        <rule label="z20+" scalemaxdenom="533" symbol="95" key="{58cf64cd-7ff4-4c44-8b6c-69d80455c2b5}"/>
      </rule>
      <rule label="Mokradła" key="{b5a1a2d1-8303-48d2-beca-4a6024d2f588}" filter="(coalesce(&quot;man_made&quot;, '') != 'bridge' AND coalesce(map_get(hstore_to_map(&quot;other_tags&quot;), 'bridge'), 'no') IN ('no','')) AND ((&quot;building&quot; IS NULL OR &quot;building&quot; = '') AND (&quot;natural&quot; = 'wetland'))">
        <rule label="z5-z15" scalemaxdenom="17471321" symbol="96" key="{02e2db62-cd2e-459f-9440-7bbc8aca3de0}" scalemindenom="8531"/>
        <rule label="z16-z17" scalemaxdenom="8531" symbol="97" key="{82a8b598-8574-4312-843a-4cf8e2f43d94}" scalemindenom="2133"/>
        <rule label="z18-z19" scalemaxdenom="2133" symbol="98" key="{e65c3668-e97e-40f5-82d0-52e630869a49}" scalemindenom="533"/>
        <rule label="z20+" scalemaxdenom="533" symbol="99" key="{ad6feaed-4f32-45a0-9de9-44c5f78cdea0}"/>
      </rule>
      <rule label="Wrzosowiska i zarośla" key="{7e702fd2-509c-487b-8c5a-817667d1ac06}" filter="(&quot;building&quot; IS NULL OR &quot;building&quot; = '') AND (&quot;natural&quot; IN ('heath','scrub'))">
        <rule label="Wrzosowiska — z5-z15" scalemaxdenom="17471321" symbol="100" key="{f3e34861-00c0-464e-8665-8a0a0a96a547}" filter="(coalesce(&quot;man_made&quot;, '') != 'bridge' AND coalesce(map_get(hstore_to_map(&quot;other_tags&quot;), 'bridge'), 'no') IN ('no','')) AND ((&quot;building&quot; IS NULL OR &quot;building&quot; = '') AND (&quot;natural&quot; = 'heath'))" scalemindenom="8531"/>
        <rule label="Wrzosowiska — z16-z17" scalemaxdenom="8531" symbol="101" key="{fb857ffa-2608-4540-8299-597fad0624c2}" filter="(coalesce(&quot;man_made&quot;, '') != 'bridge' AND coalesce(map_get(hstore_to_map(&quot;other_tags&quot;), 'bridge'), 'no') IN ('no','')) AND ((&quot;building&quot; IS NULL OR &quot;building&quot; = '') AND (&quot;natural&quot; = 'heath'))" scalemindenom="2133"/>
        <rule label="Wrzosowiska — z18-z19" scalemaxdenom="2133" symbol="102" key="{a321593a-c772-4694-af07-42efc5d7e6d2}" filter="(coalesce(&quot;man_made&quot;, '') != 'bridge' AND coalesce(map_get(hstore_to_map(&quot;other_tags&quot;), 'bridge'), 'no') IN ('no','')) AND ((&quot;building&quot; IS NULL OR &quot;building&quot; = '') AND (&quot;natural&quot; = 'heath'))" scalemindenom="533"/>
        <rule label="Wrzosowiska — z20+" scalemaxdenom="533" symbol="103" key="{e6e17f14-51e3-44c5-8a5f-c73d5b8de146}" filter="(coalesce(&quot;man_made&quot;, '') != 'bridge' AND coalesce(map_get(hstore_to_map(&quot;other_tags&quot;), 'bridge'), 'no') IN ('no','')) AND ((&quot;building&quot; IS NULL OR &quot;building&quot; = '') AND (&quot;natural&quot; = 'heath'))"/>
        <rule label="Zarośla — z5-z15" scalemaxdenom="17471321" symbol="104" key="{283127d6-eaf3-4073-9c8b-147ed13dc004}" filter="(coalesce(&quot;man_made&quot;, '') != 'bridge' AND coalesce(map_get(hstore_to_map(&quot;other_tags&quot;), 'bridge'), 'no') IN ('no','')) AND ((&quot;building&quot; IS NULL OR &quot;building&quot; = '') AND (&quot;natural&quot; = 'scrub'))" scalemindenom="8531"/>
        <rule label="Zarośla — z16-z17" scalemaxdenom="8531" symbol="105" key="{28566b9f-35c4-4c1a-94fb-1463ad7e0220}" filter="(coalesce(&quot;man_made&quot;, '') != 'bridge' AND coalesce(map_get(hstore_to_map(&quot;other_tags&quot;), 'bridge'), 'no') IN ('no','')) AND ((&quot;building&quot; IS NULL OR &quot;building&quot; = '') AND (&quot;natural&quot; = 'scrub'))" scalemindenom="2133"/>
        <rule label="Zarośla — z18-z19" scalemaxdenom="2133" symbol="106" key="{629a13ed-faf3-43ec-9bb3-f2f7f82cdedf}" filter="(coalesce(&quot;man_made&quot;, '') != 'bridge' AND coalesce(map_get(hstore_to_map(&quot;other_tags&quot;), 'bridge'), 'no') IN ('no','')) AND ((&quot;building&quot; IS NULL OR &quot;building&quot; = '') AND (&quot;natural&quot; = 'scrub'))" scalemindenom="533"/>
        <rule label="Zarośla — z20+" scalemaxdenom="533" symbol="107" key="{cb93cf82-ecd8-4ad5-a2b3-20728772c7a7}" filter="(coalesce(&quot;man_made&quot;, '') != 'bridge' AND coalesce(map_get(hstore_to_map(&quot;other_tags&quot;), 'bridge'), 'no') IN ('no','')) AND ((&quot;building&quot; IS NULL OR &quot;building&quot; = '') AND (&quot;natural&quot; = 'scrub'))"/>
      </rule>
      <rule label="Boiska i bieżnie" key="{936b2bbb-6893-4f2f-b7fb-9124d574af68}" filter="(coalesce(&quot;man_made&quot;, '') != 'bridge' AND coalesce(map_get(hstore_to_map(&quot;other_tags&quot;), 'bridge'), 'no') IN ('no','')) AND ((&quot;building&quot; IS NULL OR &quot;building&quot; = '') AND (&quot;leisure&quot; IN ('pitch','track')))">
        <rule label="z12-z15" scalemaxdenom="136495" symbol="108" key="{8c0f78d3-d640-47b0-8093-6e3905bd704e}" scalemindenom="8531"/>
        <rule label="z16-z17" scalemaxdenom="8531" symbol="109" key="{701b5a30-4c8f-4152-b862-1cda310ba2c8}" scalemindenom="2133"/>
        <rule label="z18-z19" scalemaxdenom="2133" symbol="110" key="{b4436d1b-fcca-449a-aa9b-a45b34b5f89e}" scalemindenom="533"/>
        <rule label="z20+" scalemaxdenom="533" symbol="111" key="{2775f699-7854-4d32-ba04-d217446b3b91}"/>
      </rule>
      <rule label="Obiekty sportowe" key="{f8578a88-2268-4bcf-bc1e-50c715e2b26d}" filter="(coalesce(&quot;man_made&quot;, '') != 'bridge' AND coalesce(map_get(hstore_to_map(&quot;other_tags&quot;), 'bridge'), 'no') IN ('no','')) AND ((&quot;building&quot; IS NULL OR &quot;building&quot; = '') AND (&quot;leisure&quot; IN ('sports_centre','stadium')))">
        <rule label="z10-z15" scalemaxdenom="545979" symbol="112" key="{da2854c1-b426-41e7-8f7d-3a3c29f222d1}" scalemindenom="8531"/>
        <rule label="z16-z17" scalemaxdenom="8531" symbol="113" key="{3b3f30c6-e1b7-4112-bdac-9b825225848a}" scalemindenom="2133"/>
        <rule label="z18-z19" scalemaxdenom="2133" symbol="114" key="{fd693178-5089-4fb3-83ae-6c5d788f3b28}" scalemindenom="533"/>
        <rule label="z20+" scalemaxdenom="533" symbol="115" key="{a938d52d-92f5-42aa-b629-f219fafcde02}"/>
      </rule>
      <rule label="Pola golfowe" key="{ea0705d9-6acd-4620-9aba-8b19fc5c3a03}" filter="(coalesce(&quot;man_made&quot;, '') != 'bridge' AND coalesce(map_get(hstore_to_map(&quot;other_tags&quot;), 'bridge'), 'no') IN ('no','')) AND ((&quot;building&quot; IS NULL OR &quot;building&quot; = '') AND (&quot;leisure&quot; = 'golf_course'))">
        <rule label="z10-z15" scalemaxdenom="545979" symbol="116" key="{b027508b-72aa-4655-9ab0-68e0c589384b}" scalemindenom="8531"/>
        <rule label="z16-z17" scalemaxdenom="8531" symbol="117" key="{8c1cc992-450b-44ce-a76a-8629fc90edb5}" scalemindenom="2133"/>
        <rule label="z18-z19" scalemaxdenom="2133" symbol="118" key="{a24f75d8-f140-4f72-bce3-212fb2763946}" scalemindenom="533"/>
        <rule label="z20+" scalemaxdenom="533" symbol="119" key="{87df93a1-f2ef-4f3c-b161-dddf537da2b3}"/>
      </rule>
      <rule label="Parking powierzchniowy" key="{1a0f0bd4-e3d0-4874-878c-ba9f83f41800}" filter="(coalesce(&quot;man_made&quot;, '') != 'bridge' AND coalesce(map_get(hstore_to_map(&quot;other_tags&quot;), 'bridge'), 'no') IN ('no','')) AND ((&quot;building&quot; IS NULL OR &quot;building&quot; = '') AND (&quot;amenity&quot; = 'parking'))">
        <rule label="z14-z15" scalemaxdenom="34124" symbol="120" key="{d129d697-0cac-4eb5-b23a-8bec9755d77b}" scalemindenom="8531"/>
        <rule label="z16-z17" scalemaxdenom="8531" symbol="121" key="{26cbca47-fc57-485f-bdc3-1d2f8e561c81}" scalemindenom="2133"/>
        <rule label="z18-z19" scalemaxdenom="2133" symbol="122" key="{0407ff42-fbf2-417a-a244-f3372f841dea}" scalemindenom="533"/>
        <rule label="z20+" scalemaxdenom="533" symbol="123" key="{eb30c588-07e4-4fd4-b20d-a032b7a0c48a}"/>
      </rule>
      <rule label="Szkoły i uczelnie" key="{9b1341ec-49f2-44c5-b825-5f0364b2bef0}" filter="(coalesce(&quot;man_made&quot;, '') != 'bridge' AND coalesce(map_get(hstore_to_map(&quot;other_tags&quot;), 'bridge'), 'no') IN ('no','')) AND ((&quot;building&quot; IS NULL OR &quot;building&quot; = '') AND (&quot;amenity&quot; IN ('school','college','university','kindergarten')))">
        <rule label="z10-z15" scalemaxdenom="545979" symbol="124" key="{3e766424-427c-4d0f-a4ba-529e0384fdd7}" scalemindenom="8531"/>
        <rule label="z16-z17" scalemaxdenom="8531" symbol="125" key="{89e623d7-958b-4c7e-9a07-67e3ca010561}" scalemindenom="2133"/>
        <rule label="z18-z19" scalemaxdenom="2133" symbol="126" key="{182fd0c1-61fe-4070-9277-6f6a2791e410}" scalemindenom="533"/>
        <rule label="z20+" scalemaxdenom="533" symbol="127" key="{9adbe70d-c20f-44b2-ad11-ec92f8fc533e}"/>
      </rule>
      <rule label="Szpitale" key="{62f82721-4cdf-4aae-a1c4-7355ccc0cd53}" filter="(coalesce(&quot;man_made&quot;, '') != 'bridge' AND coalesce(map_get(hstore_to_map(&quot;other_tags&quot;), 'bridge'), 'no') IN ('no','')) AND ((&quot;building&quot; IS NULL OR &quot;building&quot; = '') AND (&quot;amenity&quot; IN ('hospital','clinic')))">
        <rule label="z10-z15" scalemaxdenom="545979" symbol="128" key="{e0a439ce-f645-42e1-9e61-e2e11386d04a}" scalemindenom="8531"/>
        <rule label="z16-z17" scalemaxdenom="8531" symbol="129" key="{c452f2f5-bd65-4f92-8789-576313021c60}" scalemindenom="2133"/>
        <rule label="z18-z19" scalemaxdenom="2133" symbol="130" key="{34a0adc1-d42d-4fdf-8841-b82b26bb351b}" scalemindenom="533"/>
        <rule label="z20+" scalemaxdenom="533" symbol="131" key="{a2c2a5d2-bf43-4138-bab8-b6b3bc5f1c3b}"/>
      </rule>
      <rule label="Budynki" key="{69fb552b-ea1c-4a9c-b7eb-95f6a0482039}" filter="(coalesce(&quot;man_made&quot;, '') != 'bridge' AND coalesce(map_get(hstore_to_map(&quot;other_tags&quot;), 'bridge'), 'no') IN ('no','')) AND (&quot;building&quot; IS NOT NULL AND &quot;building&quot; != '')">
        <rule label="z14-z15" scalemaxdenom="34124" symbol="132" key="{78cc1fef-44dd-45f6-8e66-14e4f2eaca1e}" scalemindenom="8531"/>
        <rule label="z16-z17" scalemaxdenom="8531" symbol="133" key="{312219fe-9881-4ee5-b225-1f858f18e1d9}" scalemindenom="2133"/>
        <rule label="z18-z19" scalemaxdenom="2133" symbol="134" key="{9e52c7d8-4b58-4a6f-b5eb-e4f78557f16a}" scalemindenom="533"/>
        <rule label="z20+" scalemaxdenom="533" symbol="135" key="{2f3bd9ff-e712-4074-854f-2df042d1954c}"/>
      </rule>
      <rule label="Pomosty mostów (OSM Carto)" key="{457ca8d2-a619-4ada-a935-6fafb24daf6a}" filter="&quot;man_made&quot; = 'bridge' OR map_get(hstore_to_map(&quot;other_tags&quot;), 'man_made') = 'bridge'">
        <rule label="z12-z15" scalemaxdenom="136495" symbol="136" key="{01465aa2-4090-441b-823d-749f201347be}" scalemindenom="8531"/>
        <rule label="z16-z17" scalemaxdenom="8531" symbol="137" key="{69e34863-abe0-4c66-b473-557dff2ac264}" scalemindenom="2133"/>
        <rule label="z18-z19" scalemaxdenom="2133" symbol="138" key="{c6340312-54dd-443d-9bab-8a296dfb9f70}" scalemindenom="533"/>
        <rule label="z20+" scalemaxdenom="533" symbol="139" key="{8416ee08-b3d4-486a-9350-baf76f1deb3a}"/>
      </rule>
    </rules>
    <symbols>
      <symbol name="0" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="20" class="SimpleFill" locked="0" enabled="1" id="{7350cbac-b743-4e09-a070-e924c706c45d}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="255,255,255,0,rgb:1,1,1,0" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="85,81,107,255,rgb:0.33333333333333331,0.31764705882352939,0.41960784313725491,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.7" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="no" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.490, 0.875, scale_linear(@map_scale, 2133, 139770566, 0.875, 0.490))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="1" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="20" class="SimpleFill" locked="0" enabled="1" id="{7350cbac-b743-4e09-a070-e924c706c45d}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="255,255,255,0,rgb:1,1,1,0" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="85,81,107,255,rgb:0.33333333333333331,0.31764705882352939,0.41960784313725491,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.7" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="no" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.490, 0.875, scale_linear(@map_scale, 2133, 139770566, 0.875, 0.490))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="10" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="20" class="SimpleFill" locked="0" enabled="1" id="{6fdce368-e12d-465b-87dc-7ec2b25efc38}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="255,255,255,0,rgb:1,1,1,0" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="155,141,179,255,rgb:0.60784313725490191,0.55294117647058827,0.70196078431372544,1" name="outline_color" type="QString"/>
            <Option value="dash" name="outline_style" type="QString"/>
            <Option value="0.26" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="no" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.182, 0.325, scale_linear(@map_scale, 2133, 1091958, 0.325, 0.182))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="100" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="2" class="SimpleFill" locked="0" enabled="1" id="{2d483824-c691-4a86-948d-aca6f398265d}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="214,217,159,255,rgb:0.83921568627450982,0.85098039215686272,0.62352941176470589,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="214,217,159,255,rgb:0.83921568627450982,0.85098039215686272,0.62352941176470589,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 17471321, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="101" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="2" class="SimpleFill" locked="0" enabled="1" id="{2d483824-c691-4a86-948d-aca6f398265d}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="214,217,159,255,rgb:0.83921568627450982,0.85098039215686272,0.62352941176470589,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="214,217,159,255,rgb:0.83921568627450982,0.85098039215686272,0.62352941176470589,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 17471321, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="102" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="2" class="SimpleFill" locked="0" enabled="1" id="{2d483824-c691-4a86-948d-aca6f398265d}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="214,217,159,255,rgb:0.83921568627450982,0.85098039215686272,0.62352941176470589,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="214,217,159,255,rgb:0.83921568627450982,0.85098039215686272,0.62352941176470589,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 17471321, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="103" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="2" class="SimpleFill" locked="0" enabled="1" id="{2d483824-c691-4a86-948d-aca6f398265d}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="214,217,159,255,rgb:0.83921568627450982,0.85098039215686272,0.62352941176470589,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="214,217,159,255,rgb:0.83921568627450982,0.85098039215686272,0.62352941176470589,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 17471321, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="104" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="2" class="SimpleFill" locked="0" enabled="1" id="{96fcaade-6688-43f1-85ed-3bee3f2506ac}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="200,215,171,255,rgb:0.78431372549019607,0.84313725490196079,0.6705882352941176,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="200,215,171,255,rgb:0.78431372549019607,0.84313725490196079,0.6705882352941176,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 17471321, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="105" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="2" class="SimpleFill" locked="0" enabled="1" id="{96fcaade-6688-43f1-85ed-3bee3f2506ac}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="200,215,171,255,rgb:0.78431372549019607,0.84313725490196079,0.6705882352941176,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="200,215,171,255,rgb:0.78431372549019607,0.84313725490196079,0.6705882352941176,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 17471321, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="106" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="2" class="SimpleFill" locked="0" enabled="1" id="{96fcaade-6688-43f1-85ed-3bee3f2506ac}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="200,215,171,255,rgb:0.78431372549019607,0.84313725490196079,0.6705882352941176,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="200,215,171,255,rgb:0.78431372549019607,0.84313725490196079,0.6705882352941176,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 17471321, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="107" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="2" class="SimpleFill" locked="0" enabled="1" id="{96fcaade-6688-43f1-85ed-3bee3f2506ac}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="200,215,171,255,rgb:0.78431372549019607,0.84313725490196079,0.6705882352941176,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="200,215,171,255,rgb:0.78431372549019607,0.84313725490196079,0.6705882352941176,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 17471321, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="108" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="6" class="SimpleFill" locked="0" enabled="1" id="{f986d3a6-242c-4e24-ba4b-8da3cbb485e8}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="136,224,190,255,rgb:0.53333333333333333,0.8784313725490196,0.74509803921568629,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="136,224,190,255,rgb:0.53333333333333333,0.8784313725490196,0.74509803921568629,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 136495, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="109" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="6" class="SimpleFill" locked="0" enabled="1" id="{f986d3a6-242c-4e24-ba4b-8da3cbb485e8}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="136,224,190,255,rgb:0.53333333333333333,0.8784313725490196,0.74509803921568629,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="136,224,190,255,rgb:0.53333333333333333,0.8784313725490196,0.74509803921568629,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 136495, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="11" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="20" class="SimpleFill" locked="0" enabled="1" id="{6fdce368-e12d-465b-87dc-7ec2b25efc38}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="255,255,255,0,rgb:1,1,1,0" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="155,141,179,255,rgb:0.60784313725490191,0.55294117647058827,0.70196078431372544,1" name="outline_color" type="QString"/>
            <Option value="dash" name="outline_style" type="QString"/>
            <Option value="0.26" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="no" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.182, 0.325, scale_linear(@map_scale, 2133, 1091958, 0.325, 0.182))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="110" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="6" class="SimpleFill" locked="0" enabled="1" id="{f986d3a6-242c-4e24-ba4b-8da3cbb485e8}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="136,224,190,255,rgb:0.53333333333333333,0.8784313725490196,0.74509803921568629,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="136,224,190,255,rgb:0.53333333333333333,0.8784313725490196,0.74509803921568629,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 136495, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="111" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="6" class="SimpleFill" locked="0" enabled="1" id="{f986d3a6-242c-4e24-ba4b-8da3cbb485e8}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="136,224,190,255,rgb:0.53333333333333333,0.8784313725490196,0.74509803921568629,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="136,224,190,255,rgb:0.53333333333333333,0.8784313725490196,0.74509803921568629,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 136495, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="112" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="6" class="SimpleFill" locked="0" enabled="1" id="{fff29a36-17b1-4e8d-b824-f5972a02d68a}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="223,252,226,255,rgb:0.87450980392156863,0.9882352941176471,0.88627450980392153,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="12,132,22,255,rgb:0.04705882352941176,0.51764705882352946,0.08627450980392157,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 545979, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="113" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="6" class="SimpleFill" locked="0" enabled="1" id="{fff29a36-17b1-4e8d-b824-f5972a02d68a}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="223,252,226,255,rgb:0.87450980392156863,0.9882352941176471,0.88627450980392153,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="12,132,22,255,rgb:0.04705882352941176,0.51764705882352946,0.08627450980392157,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 545979, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="114" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="6" class="SimpleFill" locked="0" enabled="1" id="{fff29a36-17b1-4e8d-b824-f5972a02d68a}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="223,252,226,255,rgb:0.87450980392156863,0.9882352941176471,0.88627450980392153,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="12,132,22,255,rgb:0.04705882352941176,0.51764705882352946,0.08627450980392157,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 545979, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="115" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="6" class="SimpleFill" locked="0" enabled="1" id="{fff29a36-17b1-4e8d-b824-f5972a02d68a}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="223,252,226,255,rgb:0.87450980392156863,0.9882352941176471,0.88627450980392153,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="12,132,22,255,rgb:0.04705882352941176,0.51764705882352946,0.08627450980392157,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 545979, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="116" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="5" class="SimpleFill" locked="0" enabled="1" id="{fc7c0cb5-2c57-47a9-8155-8479b7833add}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="222,246,192,255,rgb:0.87058823529411766,0.96470588235294119,0.75294117647058822,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="222,246,192,255,rgb:0.87058823529411766,0.96470588235294119,0.75294117647058822,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 545979, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="117" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="5" class="SimpleFill" locked="0" enabled="1" id="{fc7c0cb5-2c57-47a9-8155-8479b7833add}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="222,246,192,255,rgb:0.87058823529411766,0.96470588235294119,0.75294117647058822,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="222,246,192,255,rgb:0.87058823529411766,0.96470588235294119,0.75294117647058822,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 545979, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="118" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="5" class="SimpleFill" locked="0" enabled="1" id="{fc7c0cb5-2c57-47a9-8155-8479b7833add}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="222,246,192,255,rgb:0.87058823529411766,0.96470588235294119,0.75294117647058822,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="222,246,192,255,rgb:0.87058823529411766,0.96470588235294119,0.75294117647058822,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 545979, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="119" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="5" class="SimpleFill" locked="0" enabled="1" id="{fc7c0cb5-2c57-47a9-8155-8479b7833add}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="222,246,192,255,rgb:0.87058823529411766,0.96470588235294119,0.75294117647058822,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="222,246,192,255,rgb:0.87058823529411766,0.96470588235294119,0.75294117647058822,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 545979, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="12" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="1" class="SimpleFill" locked="0" enabled="1" id="{f5ec9743-50e9-46fc-a783-c55aa6424c83}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="170,211,223,255,rgb:0.66666666666666663,0.82745098039215681,0.87450980392156863,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="170,211,223,255,rgb:0.66666666666666663,0.82745098039215681,0.87450980392156863,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.2" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.130, 0.250, scale_linear(@map_scale, 2133, 17471321, 0.250, 0.130))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="120" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="7" class="SimpleFill" locked="0" enabled="1" id="{950609f1-4d34-41ac-9613-da92e4eb7e81}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="238,238,238,255,rgb:0.93333333333333335,0.93333333333333335,0.93333333333333335,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="142,142,142,255,rgb:0.55686274509803924,0.55686274509803924,0.55686274509803924,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 34124, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="121" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="7" class="SimpleFill" locked="0" enabled="1" id="{950609f1-4d34-41ac-9613-da92e4eb7e81}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="238,238,238,255,rgb:0.93333333333333335,0.93333333333333335,0.93333333333333335,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="142,142,142,255,rgb:0.55686274509803924,0.55686274509803924,0.55686274509803924,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 34124, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="122" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="7" class="SimpleFill" locked="0" enabled="1" id="{950609f1-4d34-41ac-9613-da92e4eb7e81}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="238,238,238,255,rgb:0.93333333333333335,0.93333333333333335,0.93333333333333335,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="142,142,142,255,rgb:0.55686274509803924,0.55686274509803924,0.55686274509803924,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 34124, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="123" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="7" class="SimpleFill" locked="0" enabled="1" id="{950609f1-4d34-41ac-9613-da92e4eb7e81}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="238,238,238,255,rgb:0.93333333333333335,0.93333333333333335,0.93333333333333335,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="142,142,142,255,rgb:0.55686274509803924,0.55686274509803924,0.55686274509803924,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 34124, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="124" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="7" class="SimpleFill" locked="0" enabled="1" id="{ecccedda-4187-4a91-b28a-ef2ef2ff8341}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="255,255,229,255,rgb:1,1,0.89803921568627454,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="255,255,229,255,rgb:1,1,0.89803921568627454,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 545979, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="125" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="7" class="SimpleFill" locked="0" enabled="1" id="{ecccedda-4187-4a91-b28a-ef2ef2ff8341}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="255,255,229,255,rgb:1,1,0.89803921568627454,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="255,255,229,255,rgb:1,1,0.89803921568627454,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 545979, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="126" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="7" class="SimpleFill" locked="0" enabled="1" id="{ecccedda-4187-4a91-b28a-ef2ef2ff8341}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="255,255,229,255,rgb:1,1,0.89803921568627454,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="255,255,229,255,rgb:1,1,0.89803921568627454,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 545979, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="127" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="7" class="SimpleFill" locked="0" enabled="1" id="{ecccedda-4187-4a91-b28a-ef2ef2ff8341}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="255,255,229,255,rgb:1,1,0.89803921568627454,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="255,255,229,255,rgb:1,1,0.89803921568627454,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 545979, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="128" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="7" class="SimpleFill" locked="0" enabled="1" id="{d26c66dc-d72b-4fae-a358-fc6c53f191f0}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="255,255,229,255,rgb:1,1,0.89803921568627454,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="255,255,229,255,rgb:1,1,0.89803921568627454,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 545979, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="129" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="7" class="SimpleFill" locked="0" enabled="1" id="{d26c66dc-d72b-4fae-a358-fc6c53f191f0}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="255,255,229,255,rgb:1,1,0.89803921568627454,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="255,255,229,255,rgb:1,1,0.89803921568627454,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 545979, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="13" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="1" class="SimpleFill" locked="0" enabled="1" id="{f5ec9743-50e9-46fc-a783-c55aa6424c83}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="170,211,223,255,rgb:0.66666666666666663,0.82745098039215681,0.87450980392156863,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="170,211,223,255,rgb:0.66666666666666663,0.82745098039215681,0.87450980392156863,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.2" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.130, 0.250, scale_linear(@map_scale, 2133, 17471321, 0.250, 0.130))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="130" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="7" class="SimpleFill" locked="0" enabled="1" id="{d26c66dc-d72b-4fae-a358-fc6c53f191f0}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="255,255,229,255,rgb:1,1,0.89803921568627454,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="255,255,229,255,rgb:1,1,0.89803921568627454,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 545979, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="131" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="7" class="SimpleFill" locked="0" enabled="1" id="{d26c66dc-d72b-4fae-a358-fc6c53f191f0}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="255,255,229,255,rgb:1,1,0.89803921568627454,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="255,255,229,255,rgb:1,1,0.89803921568627454,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 545979, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="132" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="10" class="SimpleFill" locked="0" enabled="1" id="{2c6fe12c-3585-41e7-ae42-7b8bb228f29b}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="217,208,201,255,rgb:0.85098039215686272,0.81568627450980391,0.78823529411764703,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="185,169,156,255,rgb:0.72549019607843135,0.66274509803921566,0.61176470588235299,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.198" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="fillColor" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="CASE WHEN @map_scale &lt;= 17062 THEN '#D9D0C9' ELSE '#D1C6BD' END" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="CASE WHEN @map_scale &lt;= 17062 THEN 0.198 ELSE 0 END" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="133" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="10" class="SimpleFill" locked="0" enabled="1" id="{2c6fe12c-3585-41e7-ae42-7b8bb228f29b}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="217,208,201,255,rgb:0.85098039215686272,0.81568627450980391,0.78823529411764703,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="185,169,156,255,rgb:0.72549019607843135,0.66274509803921566,0.61176470588235299,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.198" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="fillColor" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="CASE WHEN @map_scale &lt;= 17062 THEN '#D9D0C9' ELSE '#D1C6BD' END" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="CASE WHEN @map_scale &lt;= 17062 THEN 0.198 ELSE 0 END" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="134" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="10" class="SimpleFill" locked="0" enabled="1" id="{2c6fe12c-3585-41e7-ae42-7b8bb228f29b}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="217,208,201,255,rgb:0.85098039215686272,0.81568627450980391,0.78823529411764703,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="185,169,156,255,rgb:0.72549019607843135,0.66274509803921566,0.61176470588235299,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.198" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="fillColor" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="CASE WHEN @map_scale &lt;= 17062 THEN '#D9D0C9' ELSE '#D1C6BD' END" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="CASE WHEN @map_scale &lt;= 17062 THEN 0.198 ELSE 0 END" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="135" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="10" class="SimpleFill" locked="0" enabled="1" id="{2c6fe12c-3585-41e7-ae42-7b8bb228f29b}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="217,208,201,255,rgb:0.85098039215686272,0.81568627450980391,0.78823529411764703,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="185,169,156,255,rgb:0.72549019607843135,0.66274509803921566,0.61176470588235299,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.198" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="fillColor" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="CASE WHEN @map_scale &lt;= 17062 THEN '#D9D0C9' ELSE '#D1C6BD' END" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="CASE WHEN @map_scale &lt;= 17062 THEN 0.198 ELSE 0 END" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="136" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="9" class="SimpleFill" locked="0" enabled="1" id="{d33a2ac6-2802-4ea8-bca5-273a9a87718b}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="184,184,184,255,rgb:0.72156862745098038,0.72156862745098038,0.72156862745098038,1" name="color" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="35,35,35,255,rgb:0.13725490196078433,0.13725490196078433,0.13725490196078433,1" name="outline_color" type="QString"/>
            <Option value="no" name="outline_style" type="QString"/>
            <Option value="0.26" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="137" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="9" class="SimpleFill" locked="0" enabled="1" id="{d33a2ac6-2802-4ea8-bca5-273a9a87718b}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="184,184,184,255,rgb:0.72156862745098038,0.72156862745098038,0.72156862745098038,1" name="color" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="35,35,35,255,rgb:0.13725490196078433,0.13725490196078433,0.13725490196078433,1" name="outline_color" type="QString"/>
            <Option value="no" name="outline_style" type="QString"/>
            <Option value="0.26" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="138" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="9" class="SimpleFill" locked="0" enabled="1" id="{d33a2ac6-2802-4ea8-bca5-273a9a87718b}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="184,184,184,255,rgb:0.72156862745098038,0.72156862745098038,0.72156862745098038,1" name="color" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="35,35,35,255,rgb:0.13725490196078433,0.13725490196078433,0.13725490196078433,1" name="outline_color" type="QString"/>
            <Option value="no" name="outline_style" type="QString"/>
            <Option value="0.26" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="139" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="9" class="SimpleFill" locked="0" enabled="1" id="{d33a2ac6-2802-4ea8-bca5-273a9a87718b}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="184,184,184,255,rgb:0.72156862745098038,0.72156862745098038,0.72156862745098038,1" name="color" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="35,35,35,255,rgb:0.13725490196078433,0.13725490196078433,0.13725490196078433,1" name="outline_color" type="QString"/>
            <Option value="no" name="outline_style" type="QString"/>
            <Option value="0.26" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="14" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="1" class="SimpleFill" locked="0" enabled="1" id="{f5ec9743-50e9-46fc-a783-c55aa6424c83}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="170,211,223,255,rgb:0.66666666666666663,0.82745098039215681,0.87450980392156863,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="170,211,223,255,rgb:0.66666666666666663,0.82745098039215681,0.87450980392156863,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.2" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.130, 0.250, scale_linear(@map_scale, 2133, 17471321, 0.250, 0.130))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="15" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="1" class="SimpleFill" locked="0" enabled="1" id="{f5ec9743-50e9-46fc-a783-c55aa6424c83}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="170,211,223,255,rgb:0.66666666666666663,0.82745098039215681,0.87450980392156863,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="170,211,223,255,rgb:0.66666666666666663,0.82745098039215681,0.87450980392156863,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.2" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.130, 0.250, scale_linear(@map_scale, 2133, 17471321, 0.250, 0.130))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="16" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="2" class="SimpleFill" locked="0" enabled="1" id="{54f3a0e9-09f7-45f7-8988-23f8c3e3df82}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="173,209,158,255,rgb:0.67843137254901964,0.81960784313725488,0.61960784313725492,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="173,209,158,255,rgb:0.67843137254901964,0.81960784313725488,0.61960784313725492,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 17471321, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="17" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="2" class="SimpleFill" locked="0" enabled="1" id="{54f3a0e9-09f7-45f7-8988-23f8c3e3df82}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="173,209,158,255,rgb:0.67843137254901964,0.81960784313725488,0.61960784313725492,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="173,209,158,255,rgb:0.67843137254901964,0.81960784313725488,0.61960784313725492,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 17471321, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="18" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="2" class="SimpleFill" locked="0" enabled="1" id="{54f3a0e9-09f7-45f7-8988-23f8c3e3df82}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="173,209,158,255,rgb:0.67843137254901964,0.81960784313725488,0.61960784313725492,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="173,209,158,255,rgb:0.67843137254901964,0.81960784313725488,0.61960784313725492,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 17471321, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="19" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="2" class="SimpleFill" locked="0" enabled="1" id="{54f3a0e9-09f7-45f7-8988-23f8c3e3df82}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="173,209,158,255,rgb:0.67843137254901964,0.81960784313725488,0.61960784313725492,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="173,209,158,255,rgb:0.67843137254901964,0.81960784313725488,0.61960784313725492,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 17471321, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="2" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="20" class="SimpleFill" locked="0" enabled="1" id="{7350cbac-b743-4e09-a070-e924c706c45d}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="255,255,255,0,rgb:1,1,1,0" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="85,81,107,255,rgb:0.33333333333333331,0.31764705882352939,0.41960784313725491,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.7" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="no" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.490, 0.875, scale_linear(@map_scale, 2133, 139770566, 0.875, 0.490))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="20" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="2" class="SimpleFill" locked="0" enabled="1" id="{80576698-bec5-4728-b755-783c10a41bfe}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="238,240,213,255,rgb:0.93333333333333335,0.94117647058823528,0.83529411764705885,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="199,201,174,255,rgb:0.7803921568627451,0.78823529411764703,0.68235294117647061,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 17471321, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="21" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="2" class="SimpleFill" locked="0" enabled="1" id="{80576698-bec5-4728-b755-783c10a41bfe}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="238,240,213,255,rgb:0.93333333333333335,0.94117647058823528,0.83529411764705885,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="199,201,174,255,rgb:0.7803921568627451,0.78823529411764703,0.68235294117647061,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 17471321, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="22" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="2" class="SimpleFill" locked="0" enabled="1" id="{80576698-bec5-4728-b755-783c10a41bfe}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="238,240,213,255,rgb:0.93333333333333335,0.94117647058823528,0.83529411764705885,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="199,201,174,255,rgb:0.7803921568627451,0.78823529411764703,0.68235294117647061,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 17471321, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="23" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="2" class="SimpleFill" locked="0" enabled="1" id="{80576698-bec5-4728-b755-783c10a41bfe}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="238,240,213,255,rgb:0.93333333333333335,0.94117647058823528,0.83529411764705885,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="199,201,174,255,rgb:0.7803921568627451,0.78823529411764703,0.68235294117647061,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 17471321, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="24" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="3" class="SimpleFill" locked="0" enabled="1" id="{e98d9d94-d8dd-476e-a4b6-899a4ee82154}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="245,220,186,255,rgb:0.96078431372549022,0.86274509803921573,0.72941176470588232,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="209,180,140,255,rgb:0.81960784313725488,0.70588235294117652,0.5490196078431373,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 545979, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="25" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="3" class="SimpleFill" locked="0" enabled="1" id="{e98d9d94-d8dd-476e-a4b6-899a4ee82154}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="245,220,186,255,rgb:0.96078431372549022,0.86274509803921573,0.72941176470588232,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="209,180,140,255,rgb:0.81960784313725488,0.70588235294117652,0.5490196078431373,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 545979, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="26" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="3" class="SimpleFill" locked="0" enabled="1" id="{e98d9d94-d8dd-476e-a4b6-899a4ee82154}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="245,220,186,255,rgb:0.96078431372549022,0.86274509803921573,0.72941176470588232,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="209,180,140,255,rgb:0.81960784313725488,0.70588235294117652,0.5490196078431373,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 545979, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="27" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="3" class="SimpleFill" locked="0" enabled="1" id="{e98d9d94-d8dd-476e-a4b6-899a4ee82154}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="245,220,186,255,rgb:0.96078431372549022,0.86274509803921573,0.72941176470588232,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="209,180,140,255,rgb:0.81960784313725488,0.70588235294117652,0.5490196078431373,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 545979, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="28" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="2" class="SimpleFill" locked="0" enabled="1" id="{9dcdcbca-16a9-4a55-992b-54380f0bd780}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="205,235,176,255,rgb:0.80392156862745101,0.92156862745098034,0.69019607843137254,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="205,235,176,255,rgb:0.80392156862745101,0.92156862745098034,0.69019607843137254,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 17471321, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="29" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="2" class="SimpleFill" locked="0" enabled="1" id="{9dcdcbca-16a9-4a55-992b-54380f0bd780}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="205,235,176,255,rgb:0.80392156862745101,0.92156862745098034,0.69019607843137254,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="205,235,176,255,rgb:0.80392156862745101,0.92156862745098034,0.69019607843137254,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 17471321, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="3" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="20" class="SimpleFill" locked="0" enabled="1" id="{7350cbac-b743-4e09-a070-e924c706c45d}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="255,255,255,0,rgb:1,1,1,0" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="85,81,107,255,rgb:0.33333333333333331,0.31764705882352939,0.41960784313725491,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.7" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="no" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.490, 0.875, scale_linear(@map_scale, 2133, 139770566, 0.875, 0.490))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="30" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="2" class="SimpleFill" locked="0" enabled="1" id="{9dcdcbca-16a9-4a55-992b-54380f0bd780}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="205,235,176,255,rgb:0.80392156862745101,0.92156862745098034,0.69019607843137254,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="205,235,176,255,rgb:0.80392156862745101,0.92156862745098034,0.69019607843137254,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 17471321, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="31" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="2" class="SimpleFill" locked="0" enabled="1" id="{9dcdcbca-16a9-4a55-992b-54380f0bd780}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="205,235,176,255,rgb:0.80392156862745101,0.92156862745098034,0.69019607843137254,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="205,235,176,255,rgb:0.80392156862745101,0.92156862745098034,0.69019607843137254,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 17471321, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="32" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="4" class="SimpleFill" locked="0" enabled="1" id="{c5483004-dfa2-4561-9a95-079ff48550c1}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="201,225,191,255,rgb:0.78823529411764703,0.88235294117647056,0.74901960784313726,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="201,225,191,255,rgb:0.78823529411764703,0.88235294117647056,0.74901960784313726,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 545979, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="33" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="4" class="SimpleFill" locked="0" enabled="1" id="{c5483004-dfa2-4561-9a95-079ff48550c1}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="201,225,191,255,rgb:0.78823529411764703,0.88235294117647056,0.74901960784313726,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="201,225,191,255,rgb:0.78823529411764703,0.88235294117647056,0.74901960784313726,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 545979, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="34" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="4" class="SimpleFill" locked="0" enabled="1" id="{c5483004-dfa2-4561-9a95-079ff48550c1}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="201,225,191,255,rgb:0.78823529411764703,0.88235294117647056,0.74901960784313726,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="201,225,191,255,rgb:0.78823529411764703,0.88235294117647056,0.74901960784313726,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 545979, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="35" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="4" class="SimpleFill" locked="0" enabled="1" id="{c5483004-dfa2-4561-9a95-079ff48550c1}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="201,225,191,255,rgb:0.78823529411764703,0.88235294117647056,0.74901960784313726,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="201,225,191,255,rgb:0.78823529411764703,0.88235294117647056,0.74901960784313726,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 545979, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="36" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="4" class="SimpleFill" locked="0" enabled="1" id="{b4d0e532-58ca-4b06-aa2c-5f36760fd861}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="174,223,163,255,rgb:0.68235294117647061,0.87450980392156863,0.63921568627450975,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="174,223,163,255,rgb:0.68235294117647061,0.87450980392156863,0.63921568627450975,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 17471321, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="37" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="4" class="SimpleFill" locked="0" enabled="1" id="{b4d0e532-58ca-4b06-aa2c-5f36760fd861}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="174,223,163,255,rgb:0.68235294117647061,0.87450980392156863,0.63921568627450975,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="174,223,163,255,rgb:0.68235294117647061,0.87450980392156863,0.63921568627450975,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 17471321, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="38" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="4" class="SimpleFill" locked="0" enabled="1" id="{b4d0e532-58ca-4b06-aa2c-5f36760fd861}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="174,223,163,255,rgb:0.68235294117647061,0.87450980392156863,0.63921568627450975,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="174,223,163,255,rgb:0.68235294117647061,0.87450980392156863,0.63921568627450975,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 17471321, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="39" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="4" class="SimpleFill" locked="0" enabled="1" id="{b4d0e532-58ca-4b06-aa2c-5f36760fd861}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="174,223,163,255,rgb:0.68235294117647061,0.87450980392156863,0.63921568627450975,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="174,223,163,255,rgb:0.68235294117647061,0.87450980392156863,0.63921568627450975,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 17471321, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="4" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="20" class="SimpleFill" locked="0" enabled="1" id="{c192020f-3b0b-4aff-b3e1-56f93c9bcdfd}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="255,255,255,0,rgb:1,1,1,0" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="141,97,139,255,rgb:0.55294117647058827,0.38039215686274508,0.54509803921568623,1" name="outline_color" type="QString"/>
            <Option value="dash" name="outline_style" type="QString"/>
            <Option value="0.45" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="no" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.315, 0.562, scale_linear(@map_scale, 2133, 17471321, 0.562, 0.315))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="40" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="4" class="SimpleFill" locked="0" enabled="1" id="{a896ca26-7a0b-4500-993b-d8c419e51a94}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="174,223,163,255,rgb:0.68235294117647061,0.87450980392156863,0.63921568627450975,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="174,223,163,255,rgb:0.68235294117647061,0.87450980392156863,0.63921568627450975,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 17471321, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="41" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="4" class="SimpleFill" locked="0" enabled="1" id="{a896ca26-7a0b-4500-993b-d8c419e51a94}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="174,223,163,255,rgb:0.68235294117647061,0.87450980392156863,0.63921568627450975,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="174,223,163,255,rgb:0.68235294117647061,0.87450980392156863,0.63921568627450975,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 17471321, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="42" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="4" class="SimpleFill" locked="0" enabled="1" id="{a896ca26-7a0b-4500-993b-d8c419e51a94}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="174,223,163,255,rgb:0.68235294117647061,0.87450980392156863,0.63921568627450975,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="174,223,163,255,rgb:0.68235294117647061,0.87450980392156863,0.63921568627450975,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 17471321, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="43" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="4" class="SimpleFill" locked="0" enabled="1" id="{a896ca26-7a0b-4500-993b-d8c419e51a94}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="174,223,163,255,rgb:0.68235294117647061,0.87450980392156863,0.63921568627450975,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="174,223,163,255,rgb:0.68235294117647061,0.87450980392156863,0.63921568627450975,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 17471321, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="44" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="5" class="SimpleFill" locked="0" enabled="1" id="{25d06a32-bf4a-4f3a-b93d-ff0206001696}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="200,250,204,255,rgb:0.78431372549019607,0.98039215686274506,0.80000000000000004,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="200,250,204,255,rgb:0.78431372549019607,0.98039215686274506,0.80000000000000004,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 545979, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="45" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="5" class="SimpleFill" locked="0" enabled="1" id="{25d06a32-bf4a-4f3a-b93d-ff0206001696}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="200,250,204,255,rgb:0.78431372549019607,0.98039215686274506,0.80000000000000004,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="200,250,204,255,rgb:0.78431372549019607,0.98039215686274506,0.80000000000000004,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 545979, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="46" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="5" class="SimpleFill" locked="0" enabled="1" id="{25d06a32-bf4a-4f3a-b93d-ff0206001696}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="200,250,204,255,rgb:0.78431372549019607,0.98039215686274506,0.80000000000000004,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="200,250,204,255,rgb:0.78431372549019607,0.98039215686274506,0.80000000000000004,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 545979, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="47" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="5" class="SimpleFill" locked="0" enabled="1" id="{25d06a32-bf4a-4f3a-b93d-ff0206001696}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="200,250,204,255,rgb:0.78431372549019607,0.98039215686274506,0.80000000000000004,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="200,250,204,255,rgb:0.78431372549019607,0.98039215686274506,0.80000000000000004,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 545979, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="48" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="5" class="SimpleFill" locked="0" enabled="1" id="{fb522446-621c-4e1c-bca6-c0f7864205e8}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="223,252,226,255,rgb:0.87450980392156863,0.9882352941176471,0.88627450980392153,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="12,132,22,255,rgb:0.04705882352941176,0.51764705882352946,0.08627450980392157,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 545979, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="49" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="5" class="SimpleFill" locked="0" enabled="1" id="{fb522446-621c-4e1c-bca6-c0f7864205e8}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="223,252,226,255,rgb:0.87450980392156863,0.9882352941176471,0.88627450980392153,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="12,132,22,255,rgb:0.04705882352941176,0.51764705882352946,0.08627450980392157,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 545979, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="5" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="20" class="SimpleFill" locked="0" enabled="1" id="{c192020f-3b0b-4aff-b3e1-56f93c9bcdfd}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="255,255,255,0,rgb:1,1,1,0" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="141,97,139,255,rgb:0.55294117647058827,0.38039215686274508,0.54509803921568623,1" name="outline_color" type="QString"/>
            <Option value="dash" name="outline_style" type="QString"/>
            <Option value="0.45" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="no" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.315, 0.562, scale_linear(@map_scale, 2133, 17471321, 0.562, 0.315))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="50" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="5" class="SimpleFill" locked="0" enabled="1" id="{fb522446-621c-4e1c-bca6-c0f7864205e8}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="223,252,226,255,rgb:0.87450980392156863,0.9882352941176471,0.88627450980392153,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="12,132,22,255,rgb:0.04705882352941176,0.51764705882352946,0.08627450980392157,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 545979, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="51" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="5" class="SimpleFill" locked="0" enabled="1" id="{fb522446-621c-4e1c-bca6-c0f7864205e8}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="223,252,226,255,rgb:0.87450980392156863,0.9882352941176471,0.88627450980392153,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="12,132,22,255,rgb:0.04705882352941176,0.51764705882352946,0.08627450980392157,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 545979, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="52" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="5" class="SimpleFill" locked="0" enabled="1" id="{d9602794-c9db-420c-8f14-afbe78601889}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="242,239,233,255,rgb:0.94901960784313721,0.93725490196078431,0.9137254901960784,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="0,128,0,255,rgb:0,0.50196078431372548,0,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 4367830, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="53" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="5" class="SimpleFill" locked="0" enabled="1" id="{d9602794-c9db-420c-8f14-afbe78601889}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="242,239,233,255,rgb:0.94901960784313721,0.93725490196078431,0.9137254901960784,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="0,128,0,255,rgb:0,0.50196078431372548,0,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 4367830, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="54" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="5" class="SimpleFill" locked="0" enabled="1" id="{d9602794-c9db-420c-8f14-afbe78601889}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="242,239,233,255,rgb:0.94901960784313721,0.93725490196078431,0.9137254901960784,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="0,128,0,255,rgb:0,0.50196078431372548,0,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 4367830, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="55" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="5" class="SimpleFill" locked="0" enabled="1" id="{d9602794-c9db-420c-8f14-afbe78601889}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="242,239,233,255,rgb:0.94901960784313721,0.93725490196078431,0.9137254901960784,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="0,128,0,255,rgb:0,0.50196078431372548,0,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 4367830, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="56" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="3" class="SimpleFill" locked="0" enabled="1" id="{fa60d72b-74ad-4408-9955-738c31230227}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="224,223,223,255,rgb:0.8784313725490196,0.87450980392156863,0.87450980392156863,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="185,185,185,255,rgb:0.72549019607843135,0.72549019607843135,0.72549019607843135,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 2183915, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="57" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="3" class="SimpleFill" locked="0" enabled="1" id="{fa60d72b-74ad-4408-9955-738c31230227}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="224,223,223,255,rgb:0.8784313725490196,0.87450980392156863,0.87450980392156863,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="185,185,185,255,rgb:0.72549019607843135,0.72549019607843135,0.72549019607843135,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 2183915, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="58" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="3" class="SimpleFill" locked="0" enabled="1" id="{fa60d72b-74ad-4408-9955-738c31230227}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="224,223,223,255,rgb:0.8784313725490196,0.87450980392156863,0.87450980392156863,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="185,185,185,255,rgb:0.72549019607843135,0.72549019607843135,0.72549019607843135,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 2183915, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="59" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="3" class="SimpleFill" locked="0" enabled="1" id="{fa60d72b-74ad-4408-9955-738c31230227}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="224,223,223,255,rgb:0.8784313725490196,0.87450980392156863,0.87450980392156863,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="185,185,185,255,rgb:0.72549019607843135,0.72549019607843135,0.72549019607843135,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 2183915, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="6" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="20" class="SimpleFill" locked="0" enabled="1" id="{c192020f-3b0b-4aff-b3e1-56f93c9bcdfd}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="255,255,255,0,rgb:1,1,1,0" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="141,97,139,255,rgb:0.55294117647058827,0.38039215686274508,0.54509803921568623,1" name="outline_color" type="QString"/>
            <Option value="dash" name="outline_style" type="QString"/>
            <Option value="0.45" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="no" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.315, 0.562, scale_linear(@map_scale, 2133, 17471321, 0.562, 0.315))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="60" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="4" class="SimpleFill" locked="0" enabled="1" id="{f4ca95fb-0924-474b-a36f-6382301acc41}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="255,214,209,255,rgb:1,0.83921568627450982,0.81960784313725488,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="217,156,149,255,rgb:0.85098039215686272,0.61176470588235299,0.58431372549019611,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 2183915, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="61" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="4" class="SimpleFill" locked="0" enabled="1" id="{f4ca95fb-0924-474b-a36f-6382301acc41}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="255,214,209,255,rgb:1,0.83921568627450982,0.81960784313725488,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="217,156,149,255,rgb:0.85098039215686272,0.61176470588235299,0.58431372549019611,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 2183915, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="62" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="4" class="SimpleFill" locked="0" enabled="1" id="{f4ca95fb-0924-474b-a36f-6382301acc41}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="255,214,209,255,rgb:1,0.83921568627450982,0.81960784313725488,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="217,156,149,255,rgb:0.85098039215686272,0.61176470588235299,0.58431372549019611,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 2183915, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="63" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="4" class="SimpleFill" locked="0" enabled="1" id="{f4ca95fb-0924-474b-a36f-6382301acc41}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="255,214,209,255,rgb:1,0.83921568627450982,0.81960784313725488,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="217,156,149,255,rgb:0.85098039215686272,0.61176470588235299,0.58431372549019611,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 2183915, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="64" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="4" class="SimpleFill" locked="0" enabled="1" id="{a2b7e235-32ed-4a59-bda7-c0175a19ae7a}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="242,218,217,255,rgb:0.94901960784313721,0.85490196078431369,0.85098039215686272,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="209,178,176,255,rgb:0.81960784313725488,0.69803921568627447,0.69019607843137254,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 2183915, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="65" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="4" class="SimpleFill" locked="0" enabled="1" id="{a2b7e235-32ed-4a59-bda7-c0175a19ae7a}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="242,218,217,255,rgb:0.94901960784313721,0.85490196078431369,0.85098039215686272,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="209,178,176,255,rgb:0.81960784313725488,0.69803921568627447,0.69019607843137254,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 2183915, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="66" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="4" class="SimpleFill" locked="0" enabled="1" id="{a2b7e235-32ed-4a59-bda7-c0175a19ae7a}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="242,218,217,255,rgb:0.94901960784313721,0.85490196078431369,0.85098039215686272,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="209,178,176,255,rgb:0.81960784313725488,0.69803921568627447,0.69019607843137254,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 2183915, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="67" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="4" class="SimpleFill" locked="0" enabled="1" id="{a2b7e235-32ed-4a59-bda7-c0175a19ae7a}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="242,218,217,255,rgb:0.94901960784313721,0.85490196078431369,0.85098039215686272,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="209,178,176,255,rgb:0.81960784313725488,0.69803921568627447,0.69019607843137254,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 2183915, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="68" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="4" class="SimpleFill" locked="0" enabled="1" id="{43aa8fb2-4a02-40f9-a4f5-cb5a09b438d3}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="235,219,232,255,rgb:0.92156862745098034,0.85882352941176465,0.90980392156862744,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="198,179,195,255,rgb:0.77647058823529413,0.70196078431372544,0.76470588235294112,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 2183915, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="69" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="4" class="SimpleFill" locked="0" enabled="1" id="{43aa8fb2-4a02-40f9-a4f5-cb5a09b438d3}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="235,219,232,255,rgb:0.92156862745098034,0.85882352941176465,0.90980392156862744,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="198,179,195,255,rgb:0.77647058823529413,0.70196078431372544,0.76470588235294112,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 2183915, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="7" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="20" class="SimpleFill" locked="0" enabled="1" id="{c192020f-3b0b-4aff-b3e1-56f93c9bcdfd}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="255,255,255,0,rgb:1,1,1,0" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="141,97,139,255,rgb:0.55294117647058827,0.38039215686274508,0.54509803921568623,1" name="outline_color" type="QString"/>
            <Option value="dash" name="outline_style" type="QString"/>
            <Option value="0.45" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="no" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.315, 0.562, scale_linear(@map_scale, 2133, 17471321, 0.562, 0.315))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="70" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="4" class="SimpleFill" locked="0" enabled="1" id="{43aa8fb2-4a02-40f9-a4f5-cb5a09b438d3}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="235,219,232,255,rgb:0.92156862745098034,0.85882352941176465,0.90980392156862744,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="198,179,195,255,rgb:0.77647058823529413,0.70196078431372544,0.76470588235294112,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 2183915, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="71" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="4" class="SimpleFill" locked="0" enabled="1" id="{43aa8fb2-4a02-40f9-a4f5-cb5a09b438d3}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="235,219,232,255,rgb:0.92156862745098034,0.85882352941176465,0.90980392156862744,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="198,179,195,255,rgb:0.77647058823529413,0.70196078431372544,0.76470588235294112,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 2183915, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="72" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="4" class="SimpleFill" locked="0" enabled="1" id="{d7d50c55-c5db-47a7-b748-3890f58ca916}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="235,219,232,255,rgb:0.92156862745098034,0.85882352941176465,0.90980392156862744,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="198,179,195,255,rgb:0.77647058823529413,0.70196078431372544,0.76470588235294112,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 545979, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="73" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="4" class="SimpleFill" locked="0" enabled="1" id="{d7d50c55-c5db-47a7-b748-3890f58ca916}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="235,219,232,255,rgb:0.92156862745098034,0.85882352941176465,0.90980392156862744,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="198,179,195,255,rgb:0.77647058823529413,0.70196078431372544,0.76470588235294112,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 545979, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="74" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="4" class="SimpleFill" locked="0" enabled="1" id="{d7d50c55-c5db-47a7-b748-3890f58ca916}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="235,219,232,255,rgb:0.92156862745098034,0.85882352941176465,0.90980392156862744,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="198,179,195,255,rgb:0.77647058823529413,0.70196078431372544,0.76470588235294112,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 545979, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="75" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="4" class="SimpleFill" locked="0" enabled="1" id="{d7d50c55-c5db-47a7-b748-3890f58ca916}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="235,219,232,255,rgb:0.92156862745098034,0.85882352941176465,0.90980392156862744,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="198,179,195,255,rgb:0.77647058823529413,0.70196078431372544,0.76470588235294112,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 545979, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="76" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="6" class="SimpleFill" locked="0" enabled="1" id="{809d17b6-60b3-4289-8eff-aecdfb229cef}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="170,203,175,255,rgb:0.66666666666666663,0.79607843137254897,0.68627450980392157,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="170,203,175,255,rgb:0.66666666666666663,0.79607843137254897,0.68627450980392157,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 545979, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="77" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="6" class="SimpleFill" locked="0" enabled="1" id="{809d17b6-60b3-4289-8eff-aecdfb229cef}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="170,203,175,255,rgb:0.66666666666666663,0.79607843137254897,0.68627450980392157,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="170,203,175,255,rgb:0.66666666666666663,0.79607843137254897,0.68627450980392157,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 545979, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="78" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="6" class="SimpleFill" locked="0" enabled="1" id="{809d17b6-60b3-4289-8eff-aecdfb229cef}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="170,203,175,255,rgb:0.66666666666666663,0.79607843137254897,0.68627450980392157,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="170,203,175,255,rgb:0.66666666666666663,0.79607843137254897,0.68627450980392157,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 545979, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="79" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="6" class="SimpleFill" locked="0" enabled="1" id="{809d17b6-60b3-4289-8eff-aecdfb229cef}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="170,203,175,255,rgb:0.66666666666666663,0.79607843137254897,0.68627450980392157,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="170,203,175,255,rgb:0.66666666666666663,0.79607843137254897,0.68627450980392157,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 545979, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="8" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="20" class="SimpleFill" locked="0" enabled="1" id="{6fdce368-e12d-465b-87dc-7ec2b25efc38}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="255,255,255,0,rgb:1,1,1,0" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="155,141,179,255,rgb:0.60784313725490191,0.55294117647058827,0.70196078431372544,1" name="outline_color" type="QString"/>
            <Option value="dash" name="outline_style" type="QString"/>
            <Option value="0.26" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="no" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.182, 0.325, scale_linear(@map_scale, 2133, 1091958, 0.325, 0.182))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="80" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="4" class="SimpleFill" locked="0" enabled="1" id="{df583175-d348-43db-8824-b6173a2ae936}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="255,85,85,255,rgb:1,0.33333333333333331,0.33333333333333331,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="255,85,85,255,rgb:1,0.33333333333333331,0.33333333333333331,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 2183915, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="81" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="4" class="SimpleFill" locked="0" enabled="1" id="{df583175-d348-43db-8824-b6173a2ae936}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="255,85,85,255,rgb:1,0.33333333333333331,0.33333333333333331,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="255,85,85,255,rgb:1,0.33333333333333331,0.33333333333333331,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 2183915, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="82" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="4" class="SimpleFill" locked="0" enabled="1" id="{df583175-d348-43db-8824-b6173a2ae936}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="255,85,85,255,rgb:1,0.33333333333333331,0.33333333333333331,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="255,85,85,255,rgb:1,0.33333333333333331,0.33333333333333331,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 2183915, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="83" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="4" class="SimpleFill" locked="0" enabled="1" id="{df583175-d348-43db-8824-b6173a2ae936}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="255,85,85,255,rgb:1,0.33333333333333331,0.33333333333333331,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="255,85,85,255,rgb:1,0.33333333333333331,0.33333333333333331,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 2183915, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="84" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="3" class="SimpleFill" locked="0" enabled="1" id="{1436ed6a-974b-44a8-a806-a2d5051b69c7}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="255,241,186,255,rgb:1,0.94509803921568625,0.72941176470588232,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="255,241,186,255,rgb:1,0.94509803921568625,0.72941176470588232,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 545979, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="85" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="3" class="SimpleFill" locked="0" enabled="1" id="{1436ed6a-974b-44a8-a806-a2d5051b69c7}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="255,241,186,255,rgb:1,0.94509803921568625,0.72941176470588232,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="255,241,186,255,rgb:1,0.94509803921568625,0.72941176470588232,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 545979, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="86" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="3" class="SimpleFill" locked="0" enabled="1" id="{1436ed6a-974b-44a8-a806-a2d5051b69c7}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="255,241,186,255,rgb:1,0.94509803921568625,0.72941176470588232,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="255,241,186,255,rgb:1,0.94509803921568625,0.72941176470588232,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 545979, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="87" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="3" class="SimpleFill" locked="0" enabled="1" id="{1436ed6a-974b-44a8-a806-a2d5051b69c7}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="255,241,186,255,rgb:1,0.94509803921568625,0.72941176470588232,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="255,241,186,255,rgb:1,0.94509803921568625,0.72941176470588232,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 545979, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="88" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="3" class="SimpleFill" locked="0" enabled="1" id="{47d6f8d2-cc42-4211-895d-7d45d3eeef1f}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="245,233,198,255,rgb:0.96078431372549022,0.9137254901960784,0.77647058823529413,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="245,233,198,255,rgb:0.96078431372549022,0.9137254901960784,0.77647058823529413,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 17471321, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="89" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="3" class="SimpleFill" locked="0" enabled="1" id="{47d6f8d2-cc42-4211-895d-7d45d3eeef1f}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="245,233,198,255,rgb:0.96078431372549022,0.9137254901960784,0.77647058823529413,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="245,233,198,255,rgb:0.96078431372549022,0.9137254901960784,0.77647058823529413,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 17471321, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="9" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="20" class="SimpleFill" locked="0" enabled="1" id="{6fdce368-e12d-465b-87dc-7ec2b25efc38}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="255,255,255,0,rgb:1,1,1,0" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="155,141,179,255,rgb:0.60784313725490191,0.55294117647058827,0.70196078431372544,1" name="outline_color" type="QString"/>
            <Option value="dash" name="outline_style" type="QString"/>
            <Option value="0.26" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="no" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.182, 0.325, scale_linear(@map_scale, 2133, 1091958, 0.325, 0.182))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="90" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="3" class="SimpleFill" locked="0" enabled="1" id="{47d6f8d2-cc42-4211-895d-7d45d3eeef1f}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="245,233,198,255,rgb:0.96078431372549022,0.9137254901960784,0.77647058823529413,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="245,233,198,255,rgb:0.96078431372549022,0.9137254901960784,0.77647058823529413,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 17471321, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="91" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="3" class="SimpleFill" locked="0" enabled="1" id="{47d6f8d2-cc42-4211-895d-7d45d3eeef1f}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="245,233,198,255,rgb:0.96078431372549022,0.9137254901960784,0.77647058823529413,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="245,233,198,255,rgb:0.96078431372549022,0.9137254901960784,0.77647058823529413,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 17471321, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="92" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="2" class="SimpleFill" locked="0" enabled="1" id="{6d11418a-ac16-4094-b7e4-c07336dcf712}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="238,229,220,255,rgb:0.93333333333333335,0.89803921568627454,0.86274509803921573,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="238,229,220,255,rgb:0.93333333333333335,0.89803921568627454,0.86274509803921573,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 17471321, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="93" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="2" class="SimpleFill" locked="0" enabled="1" id="{6d11418a-ac16-4094-b7e4-c07336dcf712}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="238,229,220,255,rgb:0.93333333333333335,0.89803921568627454,0.86274509803921573,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="238,229,220,255,rgb:0.93333333333333335,0.89803921568627454,0.86274509803921573,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 17471321, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="94" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="2" class="SimpleFill" locked="0" enabled="1" id="{6d11418a-ac16-4094-b7e4-c07336dcf712}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="238,229,220,255,rgb:0.93333333333333335,0.89803921568627454,0.86274509803921573,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="238,229,220,255,rgb:0.93333333333333335,0.89803921568627454,0.86274509803921573,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 17471321, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="95" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="2" class="SimpleFill" locked="0" enabled="1" id="{6d11418a-ac16-4094-b7e4-c07336dcf712}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="238,229,220,255,rgb:0.93333333333333335,0.89803921568627454,0.86274509803921573,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="238,229,220,255,rgb:0.93333333333333335,0.89803921568627454,0.86274509803921573,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 17471321, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="96" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="2" class="SimpleFill" locked="0" enabled="1" id="{a04519e4-d042-416e-9393-76f1fc2a474b}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="205,235,176,255,rgb:0.80392156862745101,0.92156862745098034,0.69019607843137254,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="205,235,176,255,rgb:0.80392156862745101,0.92156862745098034,0.69019607843137254,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 17471321, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="97" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="2" class="SimpleFill" locked="0" enabled="1" id="{a04519e4-d042-416e-9393-76f1fc2a474b}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="205,235,176,255,rgb:0.80392156862745101,0.92156862745098034,0.69019607843137254,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="205,235,176,255,rgb:0.80392156862745101,0.92156862745098034,0.69019607843137254,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 17471321, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="98" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="2" class="SimpleFill" locked="0" enabled="1" id="{a04519e4-d042-416e-9393-76f1fc2a474b}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="205,235,176,255,rgb:0.80392156862745101,0.92156862745098034,0.69019607843137254,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="205,235,176,255,rgb:0.80392156862745101,0.92156862745098034,0.69019607843137254,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 17471321, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol name="99" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer pass="2" class="SimpleFill" locked="0" enabled="1" id="{a04519e4-d042-416e-9393-76f1fc2a474b}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="205,235,176,255,rgb:0.80392156862745101,0.92156862745098034,0.69019607843137254,1" name="color" type="QString"/>
            <Option value="round" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="205,235,176,255,rgb:0.80392156862745101,0.92156862745098034,0.69019607843137254,1" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.15" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties" type="Map">
                <Option name="outlineWidth" type="Map">
                  <Option value="true" name="active" type="bool"/>
                  <Option value="clamp(0.098, 0.188, scale_linear(@map_scale, 2133, 17471321, 0.188, 0.098))" name="expression" type="QString"/>
                  <Option value="3" name="type" type="int"/>
                </Option>
              </Option>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
    <data-defined-properties>
      <Option type="Map">
        <Option value="" name="name" type="QString"/>
        <Option name="properties"/>
        <Option value="collection" name="type" type="QString"/>
      </Option>
    </data-defined-properties>
  </renderer-v2>
  <selection mode="Default">
    <selectionColor invalid="1"/>
  </selection>
  <labeling type="simple">
    <settings calloutType="simple">
      <text-style fontWordSpacing="0" textColor="0,0,0,255,rgb:0,0,0,1" fontSize="8" isExpression="1" previewBkgrdColor="255,255,255,255,rgb:1,1,1,1" fontLetterSpacing="0" tabStopDistanceUnit="Percentage" fieldName="with_variable('tags', hstore_to_map(&quot;other_tags&quot;), CASE WHEN @map_scale &lt;= 4265 AND (coalesce(&quot;man_made&quot;, '') != 'bridge' AND coalesce(map_get(hstore_to_map(&quot;other_tags&quot;), 'bridge'), 'no') IN ('no','')) AND &quot;building&quot; IS NOT NULL THEN map_get(@tags, 'addr:housenumber') WHEN (coalesce(&quot;man_made&quot;, '') != 'bridge' AND coalesce(map_get(hstore_to_map(&quot;other_tags&quot;), 'bridge'), 'no') IN ('no','')) AND &quot;boundary&quot; = 'administrative' AND &quot;admin_level&quot; IN ('3','4') AND @map_scale &lt;= 17471321 THEN &quot;name&quot; WHEN (coalesce(&quot;man_made&quot;, '') != 'bridge' AND coalesce(map_get(hstore_to_map(&quot;other_tags&quot;), 'bridge'), 'no') IN ('no','')) AND &quot;boundary&quot; = 'administrative' AND &quot;admin_level&quot; IN ('5','6') AND @map_scale &lt;= 2183915 THEN &quot;name&quot; WHEN (coalesce(&quot;man_made&quot;, '') != 'bridge' AND coalesce(map_get(hstore_to_map(&quot;other_tags&quot;), 'bridge'), 'no') IN ('no','')) AND &quot;boundary&quot; = 'administrative' AND &quot;admin_level&quot; IN ('7','8') AND @map_scale &lt;= 272989 THEN &quot;name&quot; WHEN (coalesce(&quot;man_made&quot;, '') != 'bridge' AND coalesce(map_get(hstore_to_map(&quot;other_tags&quot;), 'bridge'), 'no') IN ('no','')) AND &quot;boundary&quot; = 'administrative' AND &quot;admin_level&quot; IN ('9','10','11') AND @map_scale &lt;= 68247 THEN &quot;name&quot; END)" blendMode="0" fontUnderline="0" textOrientation="horizontal" tabStopDistanceMapUnitScale="3x:0,0,0,0,0,0" multilineHeight="1" fontItalic="0" fontSizeMapUnitScale="3x:0,0,0,0,0,0" allowHtml="0" fontSizeUnit="Point" forcedItalic="0" forcedBold="0" legendString="Aa" useSubstitutions="0" capitalization="0" fontWeight="50" fontFamily="Noto Sans" fontStrikeout="0" textOpacity="1" fontKerning="1" namedStyle="" multilineHeightUnit="Percentage" tabStopDistance="6">
        <families/>
        <text-buffer bufferDraw="1" bufferColor="242,239,233,255,rgb:0.94901960784313721,0.93725490196078431,0.9137254901960784,1" bufferNoFill="1" bufferSizeUnits="MM" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferJoinStyle="128" bufferBlendMode="0" bufferSize="1" bufferOpacity="1"/>
        <text-mask maskSizeUnits="MM" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskEnabled="0" maskType="0" maskSize2="1.5" maskedSymbolLayers="" maskSize="1.5" maskJoinStyle="128" maskOpacity="1"/>
        <background shapeOffsetY="0" shapeSizeX="0" shapeRadiiY="0" shapeFillColor="255,255,255,255,rgb:1,1,1,1" shapeBorderWidthUnit="MM" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeJoinStyle="64" shapeOffsetX="0" shapeSVGFile="" shapeType="0" shapeRotation="0" shapeRadiiX="0" shapeOffsetUnit="MM" shapeDraw="0" shapeSizeUnit="MM" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeBorderColor="128,128,128,255,rgb:0.50196078431372548,0.50196078431372548,0.50196078431372548,1" shapeOpacity="1" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiUnit="MM" shapeRotationType="0" shapeSizeType="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeSizeY="0" shapeBorderWidth="0" shapeBlendMode="0">
          <symbol name="fillSymbol" clip_to_extent="1" alpha="1" force_rhr="0" type="fill" is_animated="0" frame_rate="10">
            <data_defined_properties>
              <Option type="Map">
                <Option value="" name="name" type="QString"/>
                <Option name="properties"/>
                <Option value="collection" name="type" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer pass="0" class="SimpleFill" locked="0" enabled="1" id="">
              <Option type="Map">
                <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
                <Option value="255,255,255,255,rgb:1,1,1,1" name="color" type="QString"/>
                <Option value="bevel" name="joinstyle" type="QString"/>
                <Option value="0,0" name="offset" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                <Option value="MM" name="offset_unit" type="QString"/>
                <Option value="128,128,128,255,rgb:0.50196078431372548,0.50196078431372548,0.50196078431372548,1" name="outline_color" type="QString"/>
                <Option value="no" name="outline_style" type="QString"/>
                <Option value="0" name="outline_width" type="QString"/>
                <Option value="MM" name="outline_width_unit" type="QString"/>
                <Option value="solid" name="style" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option value="" name="name" type="QString"/>
                  <Option name="properties"/>
                  <Option value="collection" name="type" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </background>
        <shadow shadowOffsetGlobal="1" shadowDraw="0" shadowScale="100" shadowBlendMode="6" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowRadius="1.5" shadowColor="0,0,0,255,rgb:0,0,0,1" shadowOffsetDist="1" shadowRadiusUnit="MM" shadowRadiusAlphaOnly="0" shadowOpacity="0.69999999999999996" shadowOffsetUnit="MM" shadowUnder="0" shadowOffsetAngle="135"/>
        <dd_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </dd_properties>
        <substitutions/>
      </text-style>
      <text-format autoWrapLength="0" useMaxLineLengthForAutoWrap="1" addDirectionSymbol="0" reverseDirectionSymbol="0" formatNumbers="0" wrapChar="" placeDirectionSymbol="0" multilineAlign="3" decimals="3" leftDirectionSymbol="&lt;" rightDirectionSymbol=">" plussign="0"/>
      <placement dist="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" geometryGeneratorType="PointGeometry" geometryGeneratorEnabled="0" offsetType="0" placementFlags="10" overlapHandling="PreventOverlap" repeatDistance="0" placement="1" maxCurvedCharAngleIn="25" centroidInside="0" maxCurvedCharAngleOut="-25" lineAnchorType="0" fitInPolygonOnly="0" prioritization="PreferCloser" overrunDistance="0" maximumDistanceMapUnitScale="3x:0,0,0,0,0,0" preserveRotation="1" repeatDistanceUnits="MM" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" geometryGenerator="" polygonPlacementFlags="2" lineAnchorClipping="0" xOffset="0" overrunDistanceUnit="MM" centroidWhole="0" distMapUnitScale="3x:0,0,0,0,0,0" rotationUnit="AngleDegrees" distUnits="MM" quadOffset="4" lineAnchorPercent="0.5" layerType="UnknownGeometry" priority="5" maximumDistance="0" lineAnchorTextPoint="FollowPlacement" yOffset="0" offsetUnits="MM" allowDegraded="0" rotationAngle="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" maximumDistanceUnit="MM"/>
      <rendering obstacleFactor="1" limitNumLabels="0" labelPerPart="0" maxNumLabels="2000" scaleMin="0" fontMinPixelSize="0" zIndex="0" fontMaxPixelSize="10000" upsidedownLabels="0" obstacleType="1" scaleVisibility="1" drawLabels="1" scaleMax="17471321" unplacedVisibility="0" minFeatureSize="0" obstacle="1" fontLimitPixelSize="0" mergeLines="0"/>
      <dd_properties>
        <Option type="Map">
          <Option value="" name="name" type="QString"/>
          <Option name="properties" type="Map">
            <Option name="Size" type="Map">
              <Option value="true" name="active" type="bool"/>
              <Option value="CASE WHEN &quot;admin_level&quot; IN ('3','4') THEN CASE WHEN @map_scale &lt;= 1091958 THEN 16 ELSE 13 END WHEN &quot;admin_level&quot; IN ('5','6') THEN CASE WHEN @map_scale &lt;= 272989 THEN 14 ELSE 11 END WHEN &quot;admin_level&quot; IN ('7','8') THEN 11 WHEN &quot;admin_level&quot; IN ('9','10','11') THEN 9 ELSE 8 END" name="expression" type="QString"/>
              <Option value="3" name="type" type="int"/>
            </Option>
          </Option>
          <Option value="collection" name="type" type="QString"/>
        </Option>
      </dd_properties>
      <callout type="simple">
        <Option type="Map">
          <Option value="pole_of_inaccessibility" name="anchorPoint" type="QString"/>
          <Option value="0" name="blendMode" type="int"/>
          <Option name="ddProperties" type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
          <Option value="false" name="drawToAllParts" type="bool"/>
          <Option value="0" name="enabled" type="QString"/>
          <Option value="point_on_exterior" name="labelAnchorPoint" type="QString"/>
          <Option value="&lt;symbol name=&quot;symbol&quot; clip_to_extent=&quot;1&quot; alpha=&quot;1&quot; force_rhr=&quot;0&quot; type=&quot;line&quot; is_animated=&quot;0&quot; frame_rate=&quot;10&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer pass=&quot;0&quot; class=&quot;SimpleLine&quot; locked=&quot;0&quot; enabled=&quot;1&quot; id=&quot;{948f1d5f-08bb-4723-b55a-4ff9b3907f1b}&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;0&quot; name=&quot;align_dash_pattern&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;square&quot; name=&quot;capstyle&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;5;2&quot; name=&quot;customdash&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;customdash_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;dash_pattern_offset&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;draw_inside_polygon&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;bevel&quot; name=&quot;joinstyle&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;60,60,60,255,rgb:0.23529411764705882,0.23529411764705882,0.23529411764705882,1&quot; name=&quot;line_color&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;solid&quot; name=&quot;line_style&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0.3&quot; name=&quot;line_width&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;line_width_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;offset&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;offset_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;ring_filter&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;trim_distance_end&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;trim_distance_start&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;use_custom_dash&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol" type="QString"/>
          <Option value="0" name="minLength" type="double"/>
          <Option value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale" type="QString"/>
          <Option value="MM" name="minLengthUnit" type="QString"/>
          <Option value="0" name="offsetFromAnchor" type="double"/>
          <Option value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale" type="QString"/>
          <Option value="MM" name="offsetFromAnchorUnit" type="QString"/>
          <Option value="0" name="offsetFromLabel" type="double"/>
          <Option value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale" type="QString"/>
          <Option value="MM" name="offsetFromLabelUnit" type="QString"/>
        </Option>
      </callout>
    </settings>
  </labeling>
  <customproperties>
    <Option/>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <geometryOptions removeDuplicateNodes="0" geometryPrecision="0">
    <activeChecks type="StringList">
      <Option value="" type="QString"/>
    </activeChecks>
    <checkConfiguration/>
  </geometryOptions>
  <legend showLabelLegend="0" type="default-vector"/>
  <fieldConfiguration>
    <field configurationFlags="NoFlag" name="osm_id">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="osm_way_id">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="name">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="type">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="aeroway">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="amenity">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="admin_level">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="barrier">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="boundary">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="building">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="craft">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="geological">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="historic">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="land_area">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="landuse">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="leisure">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="man_made">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="military">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="natural">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="office">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="place">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="shop">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="sport">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="tourism">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="other_tags">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias index="0" name="" field="osm_id"/>
    <alias index="1" name="" field="osm_way_id"/>
    <alias index="2" name="" field="name"/>
    <alias index="3" name="" field="type"/>
    <alias index="4" name="" field="aeroway"/>
    <alias index="5" name="" field="amenity"/>
    <alias index="6" name="" field="admin_level"/>
    <alias index="7" name="" field="barrier"/>
    <alias index="8" name="" field="boundary"/>
    <alias index="9" name="" field="building"/>
    <alias index="10" name="" field="craft"/>
    <alias index="11" name="" field="geological"/>
    <alias index="12" name="" field="historic"/>
    <alias index="13" name="" field="land_area"/>
    <alias index="14" name="" field="landuse"/>
    <alias index="15" name="" field="leisure"/>
    <alias index="16" name="" field="man_made"/>
    <alias index="17" name="" field="military"/>
    <alias index="18" name="" field="natural"/>
    <alias index="19" name="" field="office"/>
    <alias index="20" name="" field="place"/>
    <alias index="21" name="" field="shop"/>
    <alias index="22" name="" field="sport"/>
    <alias index="23" name="" field="tourism"/>
    <alias index="24" name="" field="other_tags"/>
  </aliases>
  <splitPolicies>
    <policy policy="Duplicate" field="osm_id"/>
    <policy policy="Duplicate" field="osm_way_id"/>
    <policy policy="Duplicate" field="name"/>
    <policy policy="Duplicate" field="type"/>
    <policy policy="Duplicate" field="aeroway"/>
    <policy policy="Duplicate" field="amenity"/>
    <policy policy="Duplicate" field="admin_level"/>
    <policy policy="Duplicate" field="barrier"/>
    <policy policy="Duplicate" field="boundary"/>
    <policy policy="Duplicate" field="building"/>
    <policy policy="Duplicate" field="craft"/>
    <policy policy="Duplicate" field="geological"/>
    <policy policy="Duplicate" field="historic"/>
    <policy policy="Duplicate" field="land_area"/>
    <policy policy="Duplicate" field="landuse"/>
    <policy policy="Duplicate" field="leisure"/>
    <policy policy="Duplicate" field="man_made"/>
    <policy policy="Duplicate" field="military"/>
    <policy policy="Duplicate" field="natural"/>
    <policy policy="Duplicate" field="office"/>
    <policy policy="Duplicate" field="place"/>
    <policy policy="Duplicate" field="shop"/>
    <policy policy="Duplicate" field="sport"/>
    <policy policy="Duplicate" field="tourism"/>
    <policy policy="Duplicate" field="other_tags"/>
  </splitPolicies>
  <duplicatePolicies>
    <policy policy="Duplicate" field="osm_id"/>
    <policy policy="Duplicate" field="osm_way_id"/>
    <policy policy="Duplicate" field="name"/>
    <policy policy="Duplicate" field="type"/>
    <policy policy="Duplicate" field="aeroway"/>
    <policy policy="Duplicate" field="amenity"/>
    <policy policy="Duplicate" field="admin_level"/>
    <policy policy="Duplicate" field="barrier"/>
    <policy policy="Duplicate" field="boundary"/>
    <policy policy="Duplicate" field="building"/>
    <policy policy="Duplicate" field="craft"/>
    <policy policy="Duplicate" field="geological"/>
    <policy policy="Duplicate" field="historic"/>
    <policy policy="Duplicate" field="land_area"/>
    <policy policy="Duplicate" field="landuse"/>
    <policy policy="Duplicate" field="leisure"/>
    <policy policy="Duplicate" field="man_made"/>
    <policy policy="Duplicate" field="military"/>
    <policy policy="Duplicate" field="natural"/>
    <policy policy="Duplicate" field="office"/>
    <policy policy="Duplicate" field="place"/>
    <policy policy="Duplicate" field="shop"/>
    <policy policy="Duplicate" field="sport"/>
    <policy policy="Duplicate" field="tourism"/>
    <policy policy="Duplicate" field="other_tags"/>
  </duplicatePolicies>
  <defaults>
    <default applyOnUpdate="0" field="osm_id" expression=""/>
    <default applyOnUpdate="0" field="osm_way_id" expression=""/>
    <default applyOnUpdate="0" field="name" expression=""/>
    <default applyOnUpdate="0" field="type" expression=""/>
    <default applyOnUpdate="0" field="aeroway" expression=""/>
    <default applyOnUpdate="0" field="amenity" expression=""/>
    <default applyOnUpdate="0" field="admin_level" expression=""/>
    <default applyOnUpdate="0" field="barrier" expression=""/>
    <default applyOnUpdate="0" field="boundary" expression=""/>
    <default applyOnUpdate="0" field="building" expression=""/>
    <default applyOnUpdate="0" field="craft" expression=""/>
    <default applyOnUpdate="0" field="geological" expression=""/>
    <default applyOnUpdate="0" field="historic" expression=""/>
    <default applyOnUpdate="0" field="land_area" expression=""/>
    <default applyOnUpdate="0" field="landuse" expression=""/>
    <default applyOnUpdate="0" field="leisure" expression=""/>
    <default applyOnUpdate="0" field="man_made" expression=""/>
    <default applyOnUpdate="0" field="military" expression=""/>
    <default applyOnUpdate="0" field="natural" expression=""/>
    <default applyOnUpdate="0" field="office" expression=""/>
    <default applyOnUpdate="0" field="place" expression=""/>
    <default applyOnUpdate="0" field="shop" expression=""/>
    <default applyOnUpdate="0" field="sport" expression=""/>
    <default applyOnUpdate="0" field="tourism" expression=""/>
    <default applyOnUpdate="0" field="other_tags" expression=""/>
  </defaults>
  <constraints>
    <constraint notnull_strength="0" exp_strength="0" unique_strength="0" field="osm_id" constraints="0"/>
    <constraint notnull_strength="0" exp_strength="0" unique_strength="0" field="osm_way_id" constraints="0"/>
    <constraint notnull_strength="0" exp_strength="0" unique_strength="0" field="name" constraints="0"/>
    <constraint notnull_strength="0" exp_strength="0" unique_strength="0" field="type" constraints="0"/>
    <constraint notnull_strength="0" exp_strength="0" unique_strength="0" field="aeroway" constraints="0"/>
    <constraint notnull_strength="0" exp_strength="0" unique_strength="0" field="amenity" constraints="0"/>
    <constraint notnull_strength="0" exp_strength="0" unique_strength="0" field="admin_level" constraints="0"/>
    <constraint notnull_strength="0" exp_strength="0" unique_strength="0" field="barrier" constraints="0"/>
    <constraint notnull_strength="0" exp_strength="0" unique_strength="0" field="boundary" constraints="0"/>
    <constraint notnull_strength="0" exp_strength="0" unique_strength="0" field="building" constraints="0"/>
    <constraint notnull_strength="0" exp_strength="0" unique_strength="0" field="craft" constraints="0"/>
    <constraint notnull_strength="0" exp_strength="0" unique_strength="0" field="geological" constraints="0"/>
    <constraint notnull_strength="0" exp_strength="0" unique_strength="0" field="historic" constraints="0"/>
    <constraint notnull_strength="0" exp_strength="0" unique_strength="0" field="land_area" constraints="0"/>
    <constraint notnull_strength="0" exp_strength="0" unique_strength="0" field="landuse" constraints="0"/>
    <constraint notnull_strength="0" exp_strength="0" unique_strength="0" field="leisure" constraints="0"/>
    <constraint notnull_strength="0" exp_strength="0" unique_strength="0" field="man_made" constraints="0"/>
    <constraint notnull_strength="0" exp_strength="0" unique_strength="0" field="military" constraints="0"/>
    <constraint notnull_strength="0" exp_strength="0" unique_strength="0" field="natural" constraints="0"/>
    <constraint notnull_strength="0" exp_strength="0" unique_strength="0" field="office" constraints="0"/>
    <constraint notnull_strength="0" exp_strength="0" unique_strength="0" field="place" constraints="0"/>
    <constraint notnull_strength="0" exp_strength="0" unique_strength="0" field="shop" constraints="0"/>
    <constraint notnull_strength="0" exp_strength="0" unique_strength="0" field="sport" constraints="0"/>
    <constraint notnull_strength="0" exp_strength="0" unique_strength="0" field="tourism" constraints="0"/>
    <constraint notnull_strength="0" exp_strength="0" unique_strength="0" field="other_tags" constraints="0"/>
  </constraints>
  <constraintExpressions>
    <constraint exp="" desc="" field="osm_id"/>
    <constraint exp="" desc="" field="osm_way_id"/>
    <constraint exp="" desc="" field="name"/>
    <constraint exp="" desc="" field="type"/>
    <constraint exp="" desc="" field="aeroway"/>
    <constraint exp="" desc="" field="amenity"/>
    <constraint exp="" desc="" field="admin_level"/>
    <constraint exp="" desc="" field="barrier"/>
    <constraint exp="" desc="" field="boundary"/>
    <constraint exp="" desc="" field="building"/>
    <constraint exp="" desc="" field="craft"/>
    <constraint exp="" desc="" field="geological"/>
    <constraint exp="" desc="" field="historic"/>
    <constraint exp="" desc="" field="land_area"/>
    <constraint exp="" desc="" field="landuse"/>
    <constraint exp="" desc="" field="leisure"/>
    <constraint exp="" desc="" field="man_made"/>
    <constraint exp="" desc="" field="military"/>
    <constraint exp="" desc="" field="natural"/>
    <constraint exp="" desc="" field="office"/>
    <constraint exp="" desc="" field="place"/>
    <constraint exp="" desc="" field="shop"/>
    <constraint exp="" desc="" field="sport"/>
    <constraint exp="" desc="" field="tourism"/>
    <constraint exp="" desc="" field="other_tags"/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions/>
  <attributetableconfig sortOrder="0" actionWidgetStyle="dropDown" sortExpression="">
    <columns/>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1"></editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath></editforminitfilepath>
  <editforminitcode><![CDATA[]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <editable/>
  <labelOnTop/>
  <reuseLastValue/>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression></previewExpression>
  <mapTip enabled="1"></mapTip>
  <layerGeometryType>2</layerGeometryType>
</qgis>
