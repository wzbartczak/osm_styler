# Audyt symboli punktowych względem OpenStreetMap Carto

## Zakres i źródła

Audyt wykonano 17 września 2026 r. względem gałęzi `master` oficjalnego
repozytorium `openstreetmap-carto/openstreetmap-carto` (stan referencyjny:
commit `f328b6d575bf4a030b1432b0d9f61879844c7311`).

Źródła pierwotne:

- `style/amenity-points.mss` — POI, transport drogowy, sklepy, obiekty
  naturalne i drzewa;
- `style/stations.mss` — stacje kolejowe, przystanki kolejowe i tramwajowe;
- `style/placenames.mss` — nazwy miejscowości;
- `style/addressing.mss` — adresy;
- katalog `symbols/` — oryginalne ikony SVG OpenStreetMap Carto.

## Najważniejsze korekty

| Obiekt | Reguła OSM Carto | Implementacja QGIS |
|---|---|---|
| Restauracja, kawiarnia, fast food, pub, bar | punkt od z17, właściwy SVG od z18 | dwa symbole podrzędne: punkt z17 i oryginalny SVG z18+ |
| Dentysta | punkt od z17, SVG od z18 | punkt z17 i `amenity/dentist.svg` od z18 |
| Fontanna | znak uproszczony na z17, SVG od z18 | punkt/basen z17 i `amenity/fountain.svg` od z18 |
| Przystanek autobusowy | kwadrat z16, `highway/bus_stop.svg` od z17 | dokładnie dwa zakresy skali |
| Dworzec autobusowy | `amenity/bus_station.svg` od z16 | osobna reguła od z16 |
| Stacja kolejowa | kwadrat od z12; wzrost na z13 i z15 | trzy zakresy rozmiaru |
| Przystanek kolejowy | kwadrat od z13; wzrost na z15 | dwa zakresy rozmiaru |
| Przystanek tramwajowy | kwadrat od z14; wzrost na z15 | dwa zakresy rozmiaru |
| Parking punktowy | uproszczony znak od z17, pełna ikona od z18 | punkt z17 i ikony zależne od typu parkingu z18 |
| Supermarket i dom towarowy | pełne ikony od z16 | osobne reguły bez etapu punktowego |
| Typowe sklepy | punkt od z17, ikona właściwa dla `shop=*` od z18 | osobne reguły i oryginalne SVG dla obsługiwanych wartości |
| Bank / bankomat | bank z17, bankomat z18 | różne ikony i progi |
| Miejsce kultu | od z16, ikona zależna od `religion=*` | osobne symbole dla ośmiu religii i symbol ogólny |
| Schronisko / chata | alpine hut i wilderness hut od z13; hostel i chalet od z17 | cztery oddzielne ikony i progi |
| Lotnisko | znaczące lotniska od z10, pozostałe od z12 | rozdzielenie według `access`, `icao` i `iata` |
| Wieża / maszt | próg zależy od typu i wysokości | warianty z14–z18 wykorzystujące `height` i `tower:type` |
| Teleskop | próg zależy od typu i średnicy | warianty z14–z17 dla anten i kopuł |
| Drzewo | korona od z16, rozmiary 2,5/5/10/15/30 px | zachowane progi i rozmiary, z rozróżnieniem `leaf_type` |

## Ikony

Do pakietu dołączono 242 pliki SVG pochodzące bezpośrednio z katalogu
`symbols/` OpenStreetMap Carto. Kopie zostały wyłącznie technicznie
przystosowane do parametru koloru SVG obsługiwanego przez QGIS; geometria ikon
nie została zmieniona. Kolory odpowiadają zmiennym CartoCSS, m.in.:

- transport `#0092DA`;
- sklepy `#AC39AC`;
- zdrowie `#BF0000`;
- gastronomia `#C77400`;
- obiekty publiczne `#734A08`;
- formy terenu `#D08F55`;
- stacje `#7981B0`.

## Świadome odstępstwa

| Odstępstwo | Uzasadnienie |
|---|---|
| Brak odstępstwa rozmiaru ikon: używany jest wymiar źródłowy SVG/CSS | poprawione w 0.9.7 |
| Nazwy POI, sklepów, budynków i relacji liniowych są wyłączone | wcześniejsze wymaganie użytkownika |
| Drzewa rozdzielono na liściaste, iglaste i nieokreślone | wcześniejsze wymaganie użytkownika; OSM Carto używa jednego koloru korony |
| `natural=rock/stone` ma lokalną ikonę od z17 | wcześniejsze wymaganie użytkownika; OSM Carto nie ma odpowiadającego symbolu punktowego |
| Duże obszary parkingów nie korzystają z wyjątku `way_pixels > 750` w warstwie punktowej | sterownik OGR PBF nie udostępnia pola `way_pixels`; powierzchnie są obsługiwane w `multipolygons` |

## Wynik walidacji

- 56 nadrzędnych kategorii punktowych;
- 488 reguł podrzędnych uwzględniających warianty i zakresy skali;
- wszystkie filtry QGIS mają poprawną składnię;
- wszystkie wskazane SVG istnieją lokalnie;
- poza udokumentowanym wyjątkiem skał każdy widoczny SVG pochodzi z
  OpenStreetMap Carto.
