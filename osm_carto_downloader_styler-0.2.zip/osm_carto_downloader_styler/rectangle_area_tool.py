"""Interactive rectangle selection tool used for Overpass downloads."""

from qgis.PyQt.QtCore import Qt, pyqtSignal
from qgis.PyQt.QtGui import QColor
from qgis.core import Qgis, QgsPointXY, QgsRectangle
from qgis.gui import QgsMapTool, QgsRubberBand


class RectangleAreaTool(QgsMapTool):
    """Emit a normalized map-coordinate rectangle drawn on the canvas."""

    rectangleCreated = pyqtSignal(object)

    def __init__(self, canvas, action):
        super().__init__(canvas)
        self.canvas = canvas
        self.select_action = action
        self.setAction(action)
        self.start_point = None
        self.end_point = None
        self.dragging = False
        self.rubber_band = QgsRubberBand(canvas, Qgis.GeometryType.Polygon)
        self.rubber_band.setColor(QColor(36, 132, 255, 55))
        self.rubber_band.setStrokeColor(QColor(20, 90, 190, 220))
        self.rubber_band.setWidth(2)

    def canvasPressEvent(self, event):
        if event.button() != Qt.LeftButton:
            return
        self.start_point = self.toMapCoordinates(event.pos())
        self.end_point = self.start_point
        self.dragging = True
        self._show_rectangle()

    def canvasMoveEvent(self, event):
        if not self.dragging:
            return
        self.end_point = self.toMapCoordinates(event.pos())
        self._show_rectangle()

    def canvasReleaseEvent(self, event):
        if not self.dragging or event.button() != Qt.LeftButton:
            return
        self.end_point = self.toMapCoordinates(event.pos())
        self.dragging = False
        rectangle = self.rectangle()
        self.rubber_band.hide()
        if rectangle is not None:
            self.rectangleCreated.emit(rectangle)

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Escape:
            self.reset()
            self.deactivate()
            return
        super().keyPressEvent(event)

    def rectangle(self):
        if self.start_point is None or self.end_point is None:
            return None
        rectangle = QgsRectangle(self.start_point, self.end_point)
        rectangle.normalize()
        if rectangle.isEmpty() or rectangle.width() == 0 or rectangle.height() == 0:
            return None
        return rectangle

    def _show_rectangle(self):
        rectangle = self.rectangle()
        self.rubber_band.reset(Qgis.GeometryType.Polygon)
        if rectangle is None:
            return
        points = (
            QgsPointXY(rectangle.xMinimum(), rectangle.yMinimum()),
            QgsPointXY(rectangle.xMinimum(), rectangle.yMaximum()),
            QgsPointXY(rectangle.xMaximum(), rectangle.yMaximum()),
            QgsPointXY(rectangle.xMaximum(), rectangle.yMinimum()),
        )
        for index, point in enumerate(points):
            self.rubber_band.addPoint(point, index == len(points) - 1)
        self.rubber_band.show()

    def reset(self):
        self.start_point = None
        self.end_point = None
        self.dragging = False
        self.rubber_band.reset(Qgis.GeometryType.Polygon)

    def deactivate(self):
        self.reset()
        if self.select_action is not None:
            self.select_action.setChecked(False)
        super().deactivate()
