"""Entry point for the OSM Carto Downloader & Styler QGIS plugin."""


def classFactory(iface):
    from .pbf_style_loader import PbfStyleLoaderPlugin

    return PbfStyleLoaderPlugin(iface)
